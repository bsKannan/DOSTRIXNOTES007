export class JwtToken{
    public Jwt: string;
    public JwtExpiryDateTime: Date;
}