export class PortfolioTokenContribution{
    public TokenName: string;
    public TokenValue: number;
    public NumberOfTokens: number;
}