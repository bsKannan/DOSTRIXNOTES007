export class User{
    public UserAccount: string;
    public UserEmail: string;
    public UserName: string;
}

export class UserAccountSummary{
    
}