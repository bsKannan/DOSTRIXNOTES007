import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-callback',
  templateUrl: '../templates/callback.component.html',
  styleUrls: ['../styles/callback.component.css']
})
export class CallbackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
