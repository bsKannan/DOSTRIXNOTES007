## Initialization
`npm install`
Make sure that node version is greater or equal to v10.2.1

## Config
The config related to db, agenda, blockchain(chain id, rpc url, etc) and wallet settings can be customized at <root>/config.js

## Start Server instances
From console
1. `screen`
2. `npm start` -- this starts the node instance for api
3. 'ctrl + a d' -- detach from screen
4. `screen` -- start a new screen instance
5. `WORKER=true node agenda.js` -- this starts the agenda worker process
