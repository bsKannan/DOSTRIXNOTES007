const http = require('http');
const https = require('https');
const fs = require('fs');
var app = require('./app');

var options = {
  key: fs.readFileSync('certs/server-key.pem'),
  cert: fs.readFileSync('certs/server-crt.pem'),
  ca: fs.readFileSync('certs/server-csr.pem')
};

http.createServer(app).listen(3000 , function() {
   console.log('Express server listening on port ' + 3000);
});
https.createServer(options, app).listen(3443 , function() {
   console.log('Express server listening on port ' + 3443);
});
