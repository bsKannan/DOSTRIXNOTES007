var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var keythereum = require("keythereum");

var VerifyToken = require('./VerifyToken');
var User = require('../models/users');

router.use(bodyParser.urlencoded({ extended: false }));
router.use(bodyParser.json());
/**
 * Configure JWT
 */
var jwt = require('jsonwebtoken'); // used to create, sign, and verify tokens
var bcrypt = require('bcryptjs');
var jwtConfig = require('../config').jwtConfig; // get config file

// helper functions - TODO : Find a proper location for the same


router.post('/register', async function(req, res) {
  // TODO check all aprams

  User.findUserByEmail(User, req.body.email)
  .then (function (user, err) {
    if (err) return res.status(500).send('Error on the server.');
    if (user) return res.status(404).send('email already registered.');

    var hashedPassword = bcrypt.hashSync(req.body.password, 8);
    var dk;

    // TODO if user is registered without errors, create  wallet for users
    // HOT wallet, cold Wallet TODO
    // TODO add IP based access

    if (!req.body.iv) {
       var params = { keyBytes: 32, ivBytes: 16 };
       dk = keythereum.create(params);
    }

    const keyObj = keythereum.dump('password', dk.privateKey, dk.salt, dk.iv)
    console.log("keyObj", keyObj);

    // TODO encrypt the wallet keys
    var keys = {
      publicKey : '0x' + keyObj.address,
      privateKey : '0x' + dk.privateKey.toString("hex"),
      // publicKey : req.body.publicKey,
      // privateKey : req.body.privateKey,
      coldWallet : req.body.coldWallet,
      hotWallet : req.body.hotWallet,
      walletOwner : req.body.walletOwner
    }
    if (req.body.publicKey) {
      keys['publicKey'] = req.body.publicKey
      keys['privateKey']  = req.body.privateKey
    }
    User.create({
      name : req.body.name,
      email : req.body.email,
      password : hashedPassword,
      keys : keys,
      walletBuffer : 10 // TODO send from end user
    },
    function (err, user) {
      if (err && err.code == 11000) return res.status(500).send('email already registered.');
      if (err) return res.status(500).send("There was a problem registering the user.");

      // create a token
      var token = jwt.sign({ id: user._id }, jwtConfig.secret, {
        expiresIn: jwtConfig.token_expire_time //86400 // expires in 24 hours
      });
      res.status(200).json({ auth: true, token: token, user: user.token, wallet_address :  '0x' + keyObj.address});
    });
  });
});

router.post('/login', function(req, res) {
  User.findUserByEmail(User, req.body.email)
  .then (function (user, err) {
    if (err) return res.status(500).send('Error on the server.');
    if (!user) return res.status(404).send('No user found.');

    // check if the password is valid
    var passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
    if (!passwordIsValid) return res.status(401).send({ auth: false, token: null });

    // if user is found and password is valid
    // create a token
    var token = jwt.sign({ id: user._id }, jwtConfig.secret, {
      expiresIn: jwtConfig.token_expire_time
    });

    // return the information including token as JSON
    res.status(200).send({ auth: true, token: token });
  })
  .catch(function (error) {
    if (error) return res.status(500).send('Error on the server.');
  });
});

router.get('/logout', function(req, res) {
  res.status(200).send({ auth: false, token: null });
});

router.get('/me', VerifyToken, function(req, res, next) {
  User.findUserByID(User, req.userId)
  .then (function (user, err) {
    if (err) return res.status(500).send("There was a problem finding the user.");
    if (!user) return res.status(404).send("No user found.");
    res.status(200).send(user);
  });
});

module.exports = router;
