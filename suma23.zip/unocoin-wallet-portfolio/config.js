
var jwt = {
  'secret': 'supersecret',
  'token_expire_time': 123600
}

var db = {
	MONGOOSE_CONNECTION_STRING : 'mongodb+srv://test:test@wandx-hrbkl.mongodb.net/',
	MONGOOSE_DBNAME : 'portfolio_r1',
	AGENDA_CONNECTION_STRING : 'mongodb+srv://test:test@wandx-hrbkl.mongodb.net',
	AGENGA_DBNAME : 'portfolio_r1',
	AGENGA_COLLECTION_NAME : 'agendaJobs'
}

var blockchain = {
	RPC_URL : "http://139.59.6.36:8545",
	CHAIN_ID : '0x03',
	TRANSFER_EVENT_HASH : '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',
  PORTFOLIO_EXCHANGE_EVENT_HASH : '0x9bd58346ff5a5e57eeae68a4048357a336c8a9fd2683d06daf863cca7742224d',
  PORTFOLIO_PUBLISH_EVENT_HASH : '0x3d0a1d0067bd6dda64782674910d61fa568ec23e2291b43de278313396b11cc4',
  PORTFOLIO_DEPOSIT_TOKENS_EVENT_HASH : '0x1055e7df6c05c7671de02b516b795815b736cd021b7c38291b6e68d91da91a2c',
  PORTFOLIO_EVENT_HASH : '0x3d3dc5f62311c8d504eb0b5bf60174bb19486593410dbf78e60a3c8f8372087a',
  PORTFOLIO_BOUGHT_EVENT_HASH : '0x2b0b8aeeda63eb1d5b7ce4533b41184901969965a83432d6e6d35a08940660d7',
  // PORTFOLIO_WITHDRAWN_EVENT_HASH : '0x1055e7df6c05c7671de02b516b795815b736cd021b7c38291b6e68d91da91a2c',
}

var wallets = {
	HARD_WALLET : 0,
	SOFT_WALLET : 1,
	MAX_HARWALLETS_PER_USER : 10,
	MAX_SOFTWALLETS_PER_USER : 10
}

var webHookUrls = {
	PING_URL : 'http://localhost:3000/api/test/txping'
}


module.exports = {
	jwtConfig : jwt,
	dbConfig : db,
	blockchainConfig : blockchain,
	walletConfig : wallets,
	webhookConfig : webHookUrls
}
