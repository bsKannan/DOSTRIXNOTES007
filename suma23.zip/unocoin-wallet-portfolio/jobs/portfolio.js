const Portfolio = require('../models/portfolio');
const User = require('../models/users');
const queues = require('../queues');
const async_lib = require('async')
const BigNumber = require('bignumber.js')
// const superagent = require('superagent');
const {promisify} = require("es6-promisify");
const blockchainConfig = require('../config').blockchainConfig
const webhookConfig = require('../config').webhookConfig
var networkApis = require('../network_apis/production_apis')
const web3 = require('../web3service')

var VBPABI = [
  {
    "constant":false,
    "inputs":[

    ],
    "name":"publish",
    "outputs":[

    ],
    "payable":false,
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "constant":false,
    "inputs":[

    ],
    "name":"liquidate",
    "outputs":[

    ],
    "payable":false,
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "constant":false,
    "inputs":[
      {
        "name":"_token",
        "type":"address"
      },
      {
        "name":"_amount",
        "type":"uint256"
      }
    ],
    "name":"depositTokens",
    "outputs":[

    ],
    "payable":false,
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "constant":true,
    "inputs":[
      {
        "name":"",
        "type":"address"
      }
    ],
    "name":"assetStatus",
    "outputs":[
      {
        "name":"",
        "type":"bool"
      }
    ],
    "payable":false,
    "stateMutability":"view",
    "type":"function"
  },
  {
    "constant":false,
    "inputs":[
      {
        "name":"_token",
        "type":"address"
      },
      {
        "name":"_amount",
        "type":"uint256"
      }
    ],
    "name":"withdrawToken",
    "outputs":[

    ],
    "payable":false,
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "constant":true,
    "inputs":[
      {
        "name":"",
        "type":"address"
      },
      {
        "name":"",
        "type":"address"
      }
    ],
    "name":"fundDeposits",
    "outputs":[
      {
        "name":"",
        "type":"uint256"
      }
    ],
    "payable":false,
    "stateMutability":"view",
    "type":"function"
  },
  {
    "constant":false,
    "inputs":[

    ],
    "name":"buy",
    "outputs":[

    ],
    "payable":true,
    "stateMutability":"payable",
    "type":"function"
  },
  {
    "constant":true,
    "inputs":[
      {
        "name":"",
        "type":"uint256"
      }
    ],
    "name":"listAssets",
    "outputs":[
      {
        "name":"",
        "type":"address"
      }
    ],
    "payable":false,
    "stateMutability":"view",
    "type":"function"
  },
  {
    "constant":false,
    "inputs":[

    ],
    "name":"cancelPortfolio",
    "outputs":[

    ],
    "payable":false,
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "constant":false,
    "inputs":[
      {
        "name":"_askValue",
        "type":"uint256"
      },
      {
        "name":"_expiresAfter",
        "type":"uint256"
      },
      {
        "name":"_assets",
        "type":"address[]"
      },
      {
        "name":"_volumes",
        "type":"uint256[]"
      },
      {
        "name":"_portfolioName",
        "type":"bytes32"
      }
    ],
    "name":"updatePortfolio",
    "outputs":[

    ],
    "payable":false,
    "stateMutability":"nonpayable",
    "type":"function"
  },
  {
    "constant":true,
    "inputs":[

    ],
    "name":"currentPortfolio",
    "outputs":[
      {
        "name":"maker",
        "type":"address"
      },
      {
        "name":"currentOwnerOrSeller",
        "type":"address"
      },
      {
        "name":"valueInEther",
        "type":"uint256"
      },
      {
        "name":"expiresAt",
        "type":"uint256"
      },
      {
        "name":"name",
        "type":"bytes32"
      },
      {
        "name":"status",
        "type":"uint8"
      }
    ],
    "payable":false,
    "stateMutability":"view",
    "type":"function"
  },
  {
    "constant":true,
    "inputs":[
      {
        "name":"",
        "type":"address"
      }
    ],
    "name":"assets",
    "outputs":[
      {
        "name":"",
        "type":"uint256"
      }
    ],
    "payable":false,
    "stateMutability":"view",
    "type":"function"
  },
  {
    "constant":true,
    "inputs":[
      {
        "name":"_depositor",
        "type":"address"
      },
      {
        "name":"_token",
        "type":"address"
      }
    ],
    "name":"balanceOfToken",
    "outputs":[
      {
        "name":"",
        "type":"uint256"
      }
    ],
    "payable":false,
    "stateMutability":"view",
    "type":"function"
  },
  {
    "inputs":[
      {
        "name":"_owner",
        "type":"address"
      },
      {
        "name":"_assets",
        "type":"address[]"
      },
      {
        "name":"_volumes",
        "type":"uint256[]"
      },
      {
        "name":"_askValue",
        "type":"uint256"
      },
      {
        "name":"_expiryBlock",
        "type":"uint256"
      },
      {
        "name":"_portfolioName",
        "type":"bytes32"
      }
    ],
    "payable":false,
    "stateMutability":"nonpayable",
    "type":"constructor"
  },
  {
    "payable":true,
    "stateMutability":"payable",
    "type":"fallback"
  },
  {
    "anonymous":false,
    "inputs":[
      {
        "indexed":false,
        "name":"_ownerOrSeller",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_amount",
        "type":"uint256"
      },
      {
        "indexed":false,
        "name":"_message",
        "type":"bytes32"
      }
    ],
    "name":"PortfolioPublsihed",
    "type":"event"
  },
  {
    "anonymous":false,
    "inputs":[
      {
        "indexed":false,
        "name":"_ownerOrSeller",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_message",
        "type":"bytes32"
      }
    ],
    "name":"PortfolioEvents",
    "type":"event"
  },
  {
    "anonymous":false,
    "inputs":[
      {
        "indexed":false,
        "name":"_ownerOrSeller",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_buyer",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_amount",
        "type":"uint256"
      },
      {
        "indexed":false,
        "name":"_message",
        "type":"bytes32"
      }
    ],
    "name":"PortfolioBought",
    "type":"event"
  },
  {
    "anonymous":false,
    "inputs":[
      {
        "indexed":false,
        "name":"_depositor",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_token",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_amount",
        "type":"uint256"
      },
      {
        "indexed":false,
        "name":"_message",
        "type":"bytes32"
      }
    ],
    "name":"Deposited",
    "type":"event"
  },
  {
    "anonymous":false,
    "inputs":[
      {
        "indexed":false,
        "name":"_depositor",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_token",
        "type":"address"
      },
      {
        "indexed":false,
        "name":"_amount",
        "type":"uint256"
      },
      {
        "indexed":false,
        "name":"_message",
        "type":"bytes32"
      }
    ],
    "name":"withdrawn",
    "type":"event"
  }
];
function stripHexPrefix(str) {
  if (typeof str !== 'string')
    return str;

  return str.slice(0, 2) === '0x' ? str.slice(0, 2) : str
}
function addHexPrefix(str) {
  if (typeof str !== 'string')
    return str;
  return str.slice(0, 2) === '0x' ? str : '0x' + str
}

function removeLeadingZeros(data) {
  if (!data) return;
  data = addHexPrefix(data)
  var step1 = networkApis.web3Utils.hexToBytes(data);
  for (var i = 0; i < step1.length; i++) {
    if (step1[i] != 0) {
      step1.splice(0, i);
      break;
    }
  }
  var ret = networkApis.web3Utils.bytesToHex(step1)
  return ret;
}

function parsePortfolioEventData(tx) {
  data = tx.data;
  if (data.startsWith("0x")) {
    data = data.substr(2);
  }
  data = data.match(/.{1,64}/g);

  let portfolio = {}

  if (tx.topics[0] == blockchainConfig.PORTFOLIO_EXCHANGE_EVENT_HASH) {
    portfolio = {
      transactionHash : tx.transactionHash,
      maker : removeLeadingZeros(data[0]),
      portfolio : removeLeadingZeros(data[1]),
      fee : removeLeadingZeros(data[2]),
      hash : removeLeadingZeros(data[3]),
      message : removeLeadingZeros(data[4]),
      lastUpdated : tx.blockNumber
    }
  } else {
    portfolio = {
      address: tx.address,
      transactionHash : tx.transactionHash,
      lastUpdated : tx.blockNumber
    }
  }

  return portfolio;
}

function processTransactions(transactions) {
  let interestedTx = []
  transactions.forEach((tx, i) => {
    //console.log("tx", tx);
    let portfolio = parsePortfolioEventData(tx);
    interestedTx.push(portfolio);
  })
  //console.log("interestedTx", interestedTx)
  return {interestedTx};
}

async function portfolioAnalysis(startBlock, endBlock) {
  let new_portfolio_queue = queues.new_portfolio_queue;
  let latest_block = endBlock
  let latest_block_user = startBlock + 1
  let queueData = []

  if (!endBlock) {
  	try {
      response = await networkApis.getBlockNumber()
      ////console.log("r", response);
      latest_block = response
	  } catch(err) {
	    // log error and try after a while
      return done(err)
	  }
  }

  let hasNotifications = false;
  let errors = {
    0 : [],
    30 : [],
    90 : []
  }

  let max_loop = 100;
  while (latest_block_user <= latest_block && max_loop > 0) {
    try {
      let block = await networkApis.getLogs(null,
        latest_block_user,
        latest_block_user,
        [blockchainConfig.PORTFOLIO_EXCHANGE_EVENT_HASH,
        blockchainConfig.PORTFOLIO_PUBLISH_EVENT_HASH,
        blockchainConfig.PORTFOLIO_DEPOSIT_TOKENS_EVENT_HASH,
        blockchainConfig.PORTFOLIO_EVENT_HASH,
        blockchainConfig.PORTFOLIO_BOUGHT_EVENT_HASH,
        //blockchainConfig.PORTFOLIO_WITHDRAWN_EVENT_HASH
      ])
      let {interestedTx} = processTransactions(block)
      queueData = queueData.concat(interestedTx)
      //console.log("queueData", queueData);
    } catch(err) {
      // log the errors and maybe retry
      if (err !== 'No records found')
        errors[0].push({startBlock : latest_block_user, confirmation : 0})
    }
    latest_block_user++;
    // console.log("latest_block", latest_block_user);
    // latest_block_user = 3487700;
    max_loop--;
  }
  //console.log("latest_block_user", latest_block_user);
  for (var i = 0; i< queueData.length; i++) {
    new_portfolio_queue.add(queueData[i], function(err, id) {
    //console.log("added to q", err, id);
    });
    hasNotifications = true;
  }

  return {
    latest_block : --latest_block_user,
    hasNotifications,
    errors
  }
}

async function updateTokenBalances(totalTokenBalances, userId) {
  // let update the token balance here
  // create structures
  var newPromise = new Promise(function(resolve, reject) {
    if (!userId)
      return reject({errors : 'User Id is not valid'})
    var errors = []
    var tokens = []
    for (to in totalTokenBalances) {
      for (token in totalTokenBalances[to]) {
        tokens.push({
          tokenAddress : token,
          walletAddress : to,
          user : userId,
          balance : totalTokenBalances[to][token]
        })
      }
    }
    async_lib.each(tokens , function(t, callback) {
      Token.findOne({
        user : userId,
        tokenAddress : t.tokenAddress,
        walletAddress : t.walletAddress
      }, function(err, token) {
        if (err)
          return cb(err)
        if (!token) {
          token = new Token({
            user : userId,
            tokenAddress : t.tokenAddress,
            walletAddress : t.walletAddress,
            balance : new BigNumber(0)
          })
        }

        token.balance = token.balance.plus(t.balance)
        token.save(function(err) {
          if (err)
            return callback(err)
          callback(null)
        })
      })
    }, function(err) {
      if (err)
        return reject(err)
      return resolve(null)
    })
  })
  return newPromise
}

async function updateUserCurrentBlock(userId, latest_block) {
  if (!userId || !latest_block)
    return false
  console.log('currentBlock', latest_block);
  return User.findByIdAndUpdate(userId, {$set : {currentBlock : latest_block}}, function(err) {
  })
}

// get the detail of each token using VBPABI
async function getPortfolioTokesAndValue(VBPContract, portfolio) {
  var tokens = [];
  for (let i = 0; i < 50; i++) {
    data  = VBPContract.listAssets(JSON.stringify(i));
    if (data !== '0x') {
      ////console.log('got assset',data);
      result = VBPContract.assetStatus(data);// , (err, result) => {
      //console.log('got assetStatus', result);
      if (result === true) {
        res = VBPContract.assets(data);// , (err, res) => {
        //console.log('got assets',res)
        tokens.push({'tokenAddress': data, 'value': (new BigNumber(res).dividedBy(new BigNumber(10).pow(18))).toJSON()});
        // filterFinalData(_.uniq(this.portfolioDetails, 'contractAddress'), status);
      }
    }
  }
  return tokens;
}

// Make wallet addresses global
// Update the addresses on ackWallet
module.exports = function(agenda) {
	agenda.define('schedule portfolio tracking', function(job, done) {
    var userId = job.attrs.data ? job.attrs.data.userId : ''
    // agenda.now('track transactions for user', {userId : userId})
		agenda.every('1 seconds', 'track new portfolio', {userId : userId});
	})
	agenda.define('track new portfolio', function(job, done) {
		var userId = job.attrs.data ? job.attrs.data.userId : ''
		if (!userId) {
			done({error : 'Invalid User Id'})
		}
		User.findById(userId)
	  .then (async function (_user, error) {
	    if (error) throw { status: 500, json: { message: 'Error retrieving user data' }, skip: true };
	    if (!_user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };

      let latest_block = 1, hasNotifications = false, errors = {};

      try {
        let ret = await portfolioAnalysis(_user.currentBlock)
        if (!ret)
          return done({'message' : 'Error'})

        latest_block = ret.latest_block
        hasNotifications = ret.hasNotifications
        errors = ret.errors
        if (latest_block !== _user.currentBlock)
          await updateUserCurrentBlock(_user._id, latest_block)
      } catch(err) {
        ////console.log(err)
        return done(err)
      }

			if (hasNotifications) {
				// we can add transactions to queue here ?
        //console.log(hasNotifications);
				agenda.schedule('2 sec', 'get details of portfolio', {userId : userId}, function(err, job) {
					////console.log('get details of portfolio job posted')
				})
			}
			if (errors[0].length || errors[30].length || errors[90].length) {
				// add the block numbers to error queue and retry
				queues.error_tx_queue.add(errors[0])
				queues.error_tx_queue.add(errors[30])
				queues.error_tx_queue.add(errors[90])
        // TODO
				// agenda.now('track transaction for block', {userId : userId}, function(err, job) {
				// 	////console.log('notification ping job posted')
				// })
			}
	    done()
	  })
	  .catch (function (error) {
	    done({error : error})
	  });
	})
	// agenda.define('track transaction for block', function(job, done) {
	// 	var userId = job.attrs.data ? job.attrs.data.userId : ''
	// 	if (!userId){
	// 		done({error : 'Invalid User Id'})
	// 	}
	// 	queues.error_tx_queue.get(function(err, msg) {
	// 		if (err)
	// 			return done({error : err})
	// 		if (!msg)
	// 			return done()
  //
	// 		// var startBlock = msg.la
	// 		User.findById(userId)
	// 	  .then (async function (_user, error) {
	// 	    if (error) throw { status: 500, json: { message: 'Error retrieving user data' }, skip: true };
	// 	    if (!_user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
  //
	// 	    let wallet_addresses=addresses_to_track;
  //       let wallet_addresses=addresses_to_track
  //       if (!wallet_addresses || !wallet_addresses.length) {
  //         try {
  //           wallet = await Wallet.findOne({user : userId})
  //           wallet_addresses = addresses_to_track = wallet.softWallets
  //         } catch(err) {
  //           return done(err)
  //         }
  //       }
  //
  //       let latest_block = 1,totalTokenBalances = {},hasNotifications = false, errors = {};
  //       try {
  //         let ret = await portfolioAnalysis(wallet_addresses, msg.startBlock, msg.startBlock)
  //         if (!ret)
  //           return done({'message' : 'Error'})
  //         latest_block = ret.latest_block
  //         totalTokenBalances = ret.totalTokenBalances
  //         hasNotifications = ret.hasNotifications
  //         errors = ret.errors
  //
  //         if (totalTokenBalances && msg.confirmations == 0)
  //           await updateTokenBalances(totalTokenBalances)
  //         if (msg.confirmations == 0 && hasNotifications) {
  //           agenda.schedule('7 sec', 'get details of portfolio', {userId : userId}, function(err, job) {
  //             ////console.log('get details of portfolio job posted')
  //           })
  //         }
  //
  //       } catch(err) {
  //         ////console.log(err)
  //         return done(err)
  //       }
	// 	  	if (ret) {
  //         error_tx_queue.ack(msg.ack, function(err, id) {
  //           if (err)
  //             return done({error : err})
  //           done()
  //         })
  //       } else {
  //         // Check the logic
  //         done()
  //       }
	// 	  })
	// 	  .catch (function (error) {
	// 	    done({error : error})
	// 	  });
  //
	// 	})
  //
  //
	// })
  // This job can be scheduled for every 30mins to check if track transactions is working or not How to check if track transaction is working or not ?
  agenda.define('force track transaction', function(job, done) {});
	agenda.define('get details of portfolio', function(job, done) {
    //console.log("get details of portfolio");
    var userId = job.attrs.data ? job.attrs.data.userId : ''
    queues.new_portfolio_queue.get(async function(err, msg) {
      //console.log("get", err, msg);
      if (!msg) {
          done("no msg");
        return;
      }
      var payload = msg.payload
      //console.log("data", payload);

      let portfolio_address;
      let portfolio = {};

      if (payload.address) {
        portfolio_address = payload.address;
        console.log("updated p", payload.address);
      } else {
        portfolio_address = payload.portfolio;
        portfolio['maker'] = payload.maker;
        portfolio['fee'] = payload.fee;
        portfolio['hash'] = payload.hash;
        portfolio['message'] = payload.message;
        console.log("new p", portfolio_address);
      }

      portfolio['contractAddress'] = portfolio_address;
      portfolio['lastUpdated'] = payload.lastUpdated;

      const VBPContract = networkApis.eth.getContract(VBPABI, portfolio_address);
      //  enum Status {NONE, TRADABLE, CLOSED, REUSABLE}
      res = VBPContract.currentPortfolio();
      portfolio['owner'] = res['0'];
      portfolio['currentOwnerOrSeller'] = res['1'];
      portfolio['valueInEther'] = new BigNumber(res['2'].toJSON()).dividedBy(new BigNumber(10).pow(18));
      portfolio['expiresAt'] = res['3'].toJSON();
      portfolio['name'] = web3.toUtf8(res['4']);
      portfolio['status'] = parseInt(res['5'].toJSON());
      tokens = await getPortfolioTokesAndValue(VBPContract, portfolio);

      portfolio['tokens'] = tokens;

      console.log("portfolioDetails", portfolio);
      // 1. save to DB
      // 2. ack
      Portfolio.findOneAndUpdate( { contractAddress : portfolio_address }, portfolio, { upsert: true, new: true}, function (err, _portfolio) {
        // if (err && err.code == 11000) return console.log('already added.');
        if (err) {
          done("db error");
          return console.log('could not add portfoilio to db', err);
        }

        console.log("portfolio added success", _portfolio);

        queues.new_portfolio_queue.ack(msg.ack, function(err, id) {
          //if (err) console.log(err)
          //else console.log('Portfolio with Id :' + id + ' acked');
          done();
        });
      });
      // console.log("count", queues.new_portfolio_queue.find({ "deleted" : { "$exists" : false } }).count());
      // .finally(function() {
      agenda.schedule('10 seconds', 'get details of portfolio', {userId : userId}); 
      // })
    })
	})
}
