
const User = require('../models/users');
const Token = require('../models/tokens');
const Wallet = require('../models/wallets');
const queues = require('../queues');
const async_lib = require('async')
const BigNumber = require('bignumber.js')
const superagent = require('superagent');
const {promisify} = require("es6-promisify");
const blockchainConfig = require('../config').blockchainConfig
const webhookConfig = require('../config').webhookConfig
var networkApis = require('../network_apis/production_apis')

function stripHexPrefix(str) {
  if (typeof str !== 'string')
    return str;

  return str.slice(0, 2) === '0x' ? str.slice(0, 2) : str
}
function addHexPrefix(str) {
  if (typeof str !== 'string')
    return str;
  return str.slice(0, 2) === '0x' ? str : '0x' + str
}


// Helper functions

var addresses_to_track = []

function getAddresses() {
  return addresses_to_track
}

function removeLeadingZeros(data) {
  if (!data) return;
  data = addHexPrefix(data)
  var step1 = networkApis.web3Utils.hexToBytes(data);
  for (var i = 0; i < step1.length; i++) {
    if (step1[i] != 0) {
      step1.splice(0, i);
      break;
    }
  }
  var ret = networkApis.web3Utils.bytesToHex(step1)
  return ret;
}

function processTransactions(transactions, addresses, confirmations = 0) {
  let interestedTx = []
  let balance = {}
  transactions.forEach((tx, i) => {
    var to = removeLeadingZeros(tx.topics[2])
    if (!to)
      return {interestedTx, balance}
    var index = addresses.findIndex(item => to.toLowerCase() === item.toLowerCase())
    if (index != -1) {
      let data = {
        txHash : tx.transactionHash,
        to : to,
        confirmations : confirmations
      }
      interestedTx.push(data)

      // Calculate the deposits here
      if (confirmations == 0) {
        if (!balance[addresses[index]])
          balance[addresses[index]] = {}
        if (!balance[addresses[index]][tx.address])
          balance[addresses[index]][tx.address] = new BigNumber(0)
        balance[addresses[index]][tx.address] = balance[addresses[index]][tx.address].plus(new BigNumber(removeLeadingZeros(tx.data)))
      }
    }
  })
  return {interestedTx, balance};
}

async function transactionAnalysis_impl1(wallet_addresses, startBlock, endBlock) {
  //console.log("aa");
  let queue = queues.tx_queue;
  let pingQueue = queues.tx_ping_queue
  let latest_block = endBlock
  let latest_block_user = startBlock + 1
  let pingQueueData = []
  let queueData = []
  if (!endBlock) {
  	try {
      response = await networkApis.getBlockNumber()
      //console.log("r", response);
      latest_block = response
	  } catch(err) {
	    // log error and try after a while
      return done(err)
	  }
    //console.log("latest_block         :::",latest_block)
  }

  // Lets assume we have already fetched the data for currentBlock

  if (!wallet_addresses || !wallet_addresses.length) {
    //console.log('wallet_addresses is empty')
  	return false
  }

  let hasNotifications = false
  let errors = {
  	0 : [],
  	30 : [],
  	90 : []
  }
  let tokenBalances = {}
  // TODO : lets make this sync for now later we can add asyn
  let totalTokenBalances = {}
  let max_loop = 5;
  while(latest_block_user <= latest_block && max_loop > 0) {
    max_loop--;
    tokenBalances = {}

    //console.log("tracking", latest_block_user, latest_block);

    try {
      let block = await networkApis.getLogs(null,
        latest_block_user,
        latest_block_user,
        blockchainConfig.TRANSFER_EVENT_HASH
      )
      let {interestedTx, balance} = processTransactions(block, wallet_addresses, 0)


      tokenBalances = balance
      pingQueueData = pingQueueData.concat(interestedTx)
      queueData = queueData.concat(interestedTx)

    } catch(err) {
      // log the errors and maybe retry
      if (err !== 'No records found')
        errors[0].push({startBlock : latest_block_user, confirmation : 0})
    }

    try {
      let blockMinu30 = await networkApis.getLogs(null,
        latest_block_user - 30,
        latest_block_user - 30,
        blockchainConfig.TRANSFER_EVENT_HASH
      )
      let {interestedTx, balance} = processTransactions(blockMinu30.result, wallet_addresses, 30)
      pingQueueData.push(interestedTx)
    } catch(err) {
      // log the errors and maybe retry
      if (err !== 'No records found')
        errors[30].push({startBlock : latest_block_user - 30, confirmation : 30})
    }

    try {
      let blockMinus90 = await networkApis.getLogs(null,
        latest_block_user - 90,
        latest_block_user - 90,
        blockchainConfig.TRANSFER_EVENT_HASH
      )
      let {interestedTx, balance} = processTransactions(blockMinus90.result, wallet_addresses, 90)
      pingQueueData.push(interestedTx)
    } catch(err) {
      // log the errors and maybe retry
      if (err !== 'No records found')
        errors[90].push({startBlock : latest_block_user - 90, confirmation : 90})
    }
    for (key in tokenBalances) {
      if (!totalTokenBalances[key])
        totalTokenBalances[key] = {}
      for (t in tokenBalances[key]) {
        if (!totalTokenBalances[key][t])
          totalTokenBalances[key][t] = new BigNumber(0)
        totalTokenBalances[key][t] = totalTokenBalances[key][t].plus(tokenBalances[key][t])
      }
    }
    tokenBalances = {}
    latest_block_user++;
}



if (pingQueueData.length || queueData.length)
hasNotifications = true

try {
  await promisify(pingQueue.add.bind(pingQueue))(pingQueueData)
  await promisify(queue.add.bind(queue))(queueData)
} catch(err) {
  //console.log('error adding tx to queues : ')
  //console.log(err)
}

return {
  latest_block : --latest_block_user,
  totalTokenBalances,
  hasNotifications,
  errors
}
}

async function updateTokenBalances(totalTokenBalances, userId) {
  // let update the token balance here
  // create structures
  var newPromise = new Promise(function(resolve, reject) {
    if (!userId)
      return reject({errors : 'User Id is not valid'})
    var errors = []
    var tokens = []
    for (to in totalTokenBalances) {
      for (token in totalTokenBalances[to]) {
        tokens.push({
          tokenAddress : token,
          walletAddress : to,
          user : userId,
          balance : totalTokenBalances[to][token]
        })
      }
    }
    async_lib.each(tokens , function(t, callback) {
      Token.findOne({
        user : userId,
        tokenAddress : t.tokenAddress,
        walletAddress : t.walletAddress
      }, function(err, token) {
        if (err)
          return cb(err)
        if (!token) {
          token = new Token({
            user : userId,
            tokenAddress : t.tokenAddress,
            walletAddress : t.walletAddress,
            balance : new BigNumber(0)
          })
        }

        token.balance = token.balance.plus(t.balance)
        token.save(function(err) {
          if (err)
            return callback(err)
          callback(null)
        })
      })
    }, function(err) {
      if (err)
        return reject(err)
      return resolve(null)
    })
  })
  return newPromise
}

async function updateUserCurrentBlock(userId, latest_block) {

  if (!userId || !latest_block)
    return false
  return User.findByIdAndUpdate(userId, {$set : {currentBlock : latest_block}}, function(err) {
    //console.log('User currentBlock Updated')
  })
}

// Make wallet addresses global
// Update the addresses on ackWallet
module.exports = function(agenda) {
	agenda.define('schedule transaction tracking', function(job, done) {
    var userId = job.attrs.data ? job.attrs.data.userId : ''
    // agenda.now('track transactions for user', {userId : userId})
		agenda.every('15 seconds', 'track transactions for user', {userId : userId});
	})
  agenda.define('update addresses', function(job, done) {
    var userId = job.attrs.data ? job.attrs.data.userId : ''
    Wallet.findOne({user : userId})
    .then(function(wallet, err) {
      if (err)
        return done({errors : err})
      if (!wallet)
        return done({errors : 'Wallet not found for user : ' + userId})
      // We only track balance for softwallets
      let addresses = wallet.softWallets
      addresses_to_track = addresses
    })
    .catch(function(err) {
      // log it
      //console.log('Error')
      //console.log(arguments)
    })
  })
	agenda.define('track transactions for user', function(job, done) {
		var userId = job.attrs.data ? job.attrs.data.userId : ''
		if (!userId){
			done({error : 'Invalid User Id'})
		}
		User.findById(userId)
	  .then (async function (_user, error) {
	    if (error) throw { status: 500, json: { message: 'Error retrieving user data' }, skip: true };
	    if (!_user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };

      let wallet_addresses=addresses_to_track
      //console.log("addresses_to_track              ::",addresses_to_track)
      if (!wallet_addresses || !wallet_addresses.length) {
        try {
          wallet = await Wallet.findOne({user : userId})
          wallet_addresses = addresses_to_track = wallet.softWallets
        } catch(err) {
          return done(err)
        }
      }
      let latest_block = 1, totalTokenBalances = {},hasNotifications = false, errors = {};
      try {
        let ret = await transactionAnalysis_impl1(wallet_addresses, _user.currentBlock)
        if (!ret)
          return done({'message' : 'Error'})

        latest_block = ret.latest_block
        totalTokenBalances = ret.totalTokenBalances
        hasNotifications = ret.hasNotifications
        errors = ret.errors

        if (latest_block !== _user.currentBlock)
          await updateUserCurrentBlock(_user._id, latest_block)
        if (totalTokenBalances)
          await updateTokenBalances(totalTokenBalances, _user._id)
      } catch(err) {
        //console.log(err)
        return done(err)
      }

			if (hasNotifications) {
				// we can add transactions to queue here ?
				agenda.schedule('7 sec', 'ping client on new tx', {userId : userId}, function(err, job) {
					//console.log('ping client on new tx job posted')
				})
			}
			if (errors[0].length || errors[30].length || errors[90].length) {
				// add the block numbers to error queue and retry
				queues.error_tx_queue.add(errors[0])
				queues.error_tx_queue.add(errors[30])
				queues.error_tx_queue.add(errors[90])
				agenda.now('track transaction for block', {userId : userId}, function(err, job) {
					//console.log('notification ping job posted')
				})
			}
	    done()
	  })
	  .catch (function (error) {
	    done({error : error})
	  });
	})
	agenda.define('track transaction for block', function(job, done) {
		var userId = job.attrs.data ? job.attrs.data.userId : ''
		if (!userId){
			done({error : 'Invalid User Id'})
		}
		queues.error_tx_queue.get(function(err, msg) {
			if (err)
				return done({error : err})
			if (!msg)
				return done()

			// var startBlock = msg.la
			User.findById(userId)
		  .then (async function (_user, error) {
		    if (error) throw { status: 500, json: { message: 'Error retrieving user data' }, skip: true };
		    if (!_user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };

		    let wallet_addresses=addresses_to_track;
        // let wallet_addresses=addresses_to_track
        if (!wallet_addresses || !wallet_addresses.length) {
          try {
            wallet = await Wallet.findOne({user : userId})
            wallet_addresses = addresses_to_track = wallet.softWallets
          } catch(err) {
            return done(err)
          }
        }

        let latest_block = 1,totalTokenBalances = {},hasNotifications = false, errors = {};
        try {
          let ret = await transactionAnalysis_impl1(wallet_addresses, msg.startBlock, msg.startBlock)
          if (!ret)
            return done({'message' : 'Error'})
          latest_block = ret.latest_block
          totalTokenBalances = ret.totalTokenBalances
          hasNotifications = ret.hasNotifications
          errors = ret.errors

          if (totalTokenBalances && msg.confirmations == 0)
            await updateTokenBalances(totalTokenBalances)
          if (msg.confirmations == 0 && hasNotifications) {
            agenda.schedule('7 sec', 'ping client on new tx', {userId : userId}, function(err, job) {
              //console.log('ping client on new tx job posted')
            })
          }

        } catch(err) {
          //console.log(err)
          return done(err)
        }
		  	if (ret) {
          error_tx_queue.ack(msg.ack, function(err, id) {
            if (err)
              return done({error : err})
            done()
          })
        } else {
          // Check the logic
          done()
        }
		  })
		  .catch (function (error) {
		    done({error : error})
		  });

		})


	})
	agenda.define('force track transaction', function(job, done) {
		// This job can be scheduled for every 30mins to check if track transactions is working or not
		// How to check if track transaction is working or not ?

	})

	agenda.define('ping client on new tx', function(job, done) {
    // is this needed ?
    var userId = job.attrs.data ? job.attrs.data.userId : ''

    queues.tx_ping_queue.get(function(err, msg) {
      if (!msg)
        return;
      var payload = msg.payload
      var data = {
        txHash : payload.txHash,
        confirmations : payload.confirmations
      }
      var p = superagent.post(webhookConfig.PING_URL)
      .send(data)
      .retry(3)
      .then(function(res) {
        if (res.ok) {
          queues.tx_ping_queue.ack(msg.ack, function(err, id) {
            if (err)
              console.log(err)
            else
              console.log('Tx in ping queue with Id :' + id + ' acked')
          })
        } else {
          //console.log('Error pinging the webhook')
        }
        done()
      })
      .catch(function(err) {
        console.log(err)
        done()
      })
      .finally(function() {
        agenda.schedule('5 seconds', 'ping client on new tx', {userId : userId})
      })
    })
	})

}
