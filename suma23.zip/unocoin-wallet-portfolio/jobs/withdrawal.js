
var queues = require('../queues');

var networkApis = require('../network_apis/production_apis')
var User = require('../models/users');
var Token = require('../models/tokens');
var Wallet = require('../models/wallets');
var async_lib = require('async')
const fs = require('fs');
const solc = require('solc');
const Web3 = require('web3')
const web3 = new Web3()
const BigNumber = require('bignumber.js')
const {sign} = require('@warren-bank/ethereumjs-tx-sign');
const blockchainConfig = require('../config').blockchainConfig


function pingMessage(ack) {
  queues.withdrawal_queue.ping(ack, function(err, id) {
  });
}

async function withdrawTokenLoop(user, msg) {

	return new Promise((resolve, reject) => {
		console.log('Comes to this :' + msg)
		let cold_balance, user_balance, hot_balance, to_cold_wallet = true;
	  let _walletContract;
	  let wallet_address = msg.payload.wallet_address;
	  let token_address = msg.payload.token_address;
		let token_amount = web3.toBigNumber(msg.payload.token_amount);
	  // check CS and HS balances for the token
	  // TODO one time only
	  let wc_input = fs.readFileSync(__root + './contracts/WalletContract.sol').toString();
	  wc_input = wc_input.replace(/COLD_WALLET/g, user.keys.coldWallet);
	  wc_input = wc_input.replace(/HOT_WALLET/g, user.keys.hotWallet);
	  wc_input = wc_input.replace(/WALLET_OWNER/g, user.keys.walletOwner);
	  const output = solc.compile(wc_input, 1);
		const contract_interface = output.contracts[':WalletContract'].interface;

	  _walletContract = networkApis.eth.getContract(JSON.parse(contract_interface), wallet_address);

	  if (!user.keys.coldWallet || !user.keys.hotWallet) {
	      return reject({error : 'Cold Wallet, HotWallet'})
	  }

		// pingMessage(msg.ack);
		console.log("a", token_address,wallet_address, user.keys.publicKey);
		user_balance  = _walletContract.getBalance(token_address, wallet_address);
		console.log("user_balance", user_balance);

	  // .then(function (result) {
	  //   user_balance = result;

	  //   if (user_balance <= 0) {
	  //     throw new Error("user balance is already zero");
	  //   }
	  //   console.log("user_balance", user_balance);
	  pingMessage(msg.ack);
		//   return
		cold_balance = _walletContract.getBalance(token_address, user.keys.coldWallet);
		console.log("cold_balance", cold_balance);

	  // .then(function (result) {
	  //     cold_balance = result;
	  //     console.log("cold_balance", cold_balance);
	  pingMessage(msg.ack);
		hot_balance = _walletContract.getBalance(token_address, user.keys.hotWallet);
		console.log("hot_balance", hot_balance);

	  // })
	  // .then(function (result) {
	      //console.log("hot_balance", result);
	  // hot_balance = result;
    //TODO
		// if (hot_balance.isEqualTo(new BigNumber(0))) {
	  //     to_cold_wallet = false;
	  // } else {
		// 	let percentage = (hot_balance.multipliedBy(new BigNumber(100))).dividedBy(hot_balance.plus(cold_balance));
		// 	if (percentage.comparedTo(new BigNumber(0)) < 1) {
		// 		to_cold_wallet = false;
		// 	}
	  // }
	  networkApis.getTransactionCount(user.keys.publicKey, "pending")
	  .then(function (txcount) {
			console.log("txcount",txcount);
	    if (!txcount) {
	      throw new Error("There was an error. Try again please!");
			}

	    if (token_amount.comparedTo(user_balance) == 1) {
	        token_amount = user_balance;
			}

	   	console.log(token_address, token_amount, to_cold_wallet, user.keys.publicKey);

			var data = _walletContract.takeAssetOut.getData(token_address, 2, to_cold_wallet);
			console.log("data", data);
			// , {from: user.keys.publicKey}
			const txData = {
			 from: user.keys.publicKey,
			 nonce:  networkApis.web3Utils.toHex(txcount),
	     gasPrice: networkApis.web3Utils.toHex(20000000000), // 20 gwei
	     to: wallet_address,
	     gasLimit: networkApis.web3Utils.toHex(4000000),   //145230
	     value:    '0x00',
	     data:     data,
	     chainId: CHAINID// Ropsten
	    }
	    const {rawTx} = sign(txData, user.keys.privateKey);
	    pingMessage(msg.ack);
	    return networkApis.eth.sendSignedTransaction('0x' + rawTx);
	  })
	  .then(function (receipt, error) {
	    if (error) {
				// TODO
				console.log("errror=>",error)
			}
			console.log(receipt, error);
	    queues.withdrawal_queue.ack(msg.ack , function(err, id) {

	      resolve()
	    });
	  })
	  .catch (function (error) {
	    reject(error)
	  });
	})

}


/*
db.token.update({"tokenAddress" : "0x60efdece78d8babae13d31f467b171ef9c3a1702} { $set : { status: 0}});
*/

async function batchWithdrawal(userId, totalAmount, tokenAddress, to_address) {
	return new Promise((resolve, reject) => {
		async_lib.waterfall([
	    function(callback) {
	      // Get token data
	      console.log({
	        user : userId,
	        tokenAddress : tokenAddress,
	        status : 0
	      })
	      Token.find({
	        user : userId,
	        tokenAddress : tokenAddress,
	        status : 0
	      })
	      .sort({balance : -1})
	      .limit(10)
	      .exec(function(err, tokens) {
	        if (err)
	          return callback({status : 500, message : err})
	        if (!tokens || !tokens.length)
	        	return callback({status : 404, message : 'User does not have any wallet'})
	        console.log('tokens')
	        console.log(tokens)
	        // Update the token data
	        callback(null, tokens)
	      })
	    },
	    function(tokens, callback) {
	    	User.findById(userId, function(err, user) {
	    		if (err)
	    			return callback({status : 500, error : err})
	    		return callback(null, tokens, user)
	    	})
	    },
	    function(tokens, user, callback) {
	      let wc_input = fs.readFileSync(__root + './contracts/BatchTransfer.sol').toString();
	      wc_input = wc_input.replace(/WALLET_OWNER/g, user.keys.walletOwner);

	      const output = solc.compile(wc_input, 1);
	      const contract_interface = output.contracts[':BatchTransfer'].interface;
				_batchTransferContract = networkApis.eth.getContract(JSON.parse(contract_interface), user.batchTransferContract);
				// console.log("_batchTransferContract..........................",_batchTransferContract)
	      return callback(null, tokens, _batchTransferContract, user)
	    },
	    function(tokenData, _batchTransferContract, user, callback) {
				// get Address for probable scenario
	      var tAmount = new BigNumber(totalAmount.toString())

	      console.log('tokenData')
	      console.log(tokenData)
	      var from_addresses = []
	      var amounts = []
	      for (var i = 0; i < tokenData.length && !tAmount.isZero(); i++) {
	        var token = tokenData[i]
					var tokenBalance = new BigNumber(token.balance)
	        if (tokenBalance.isZero())
	          continue;
					var tempAmount = (new BigNumber(tAmount)).minus(token.balance)

	        if (tempAmount.isNegative()) {
	          from_addresses.push(token.walletAddress)
	          amounts.push(tAmount.toString())
	          tAmount = new BigNumber(0)
	          break;
	        } else if (tempAmount.isPositive()){
	          from_addresses.push(token.walletAddress)
	          amounts.push(token.balance.toString())
	          tAmount = tAmount.minus(token.balance)
					}
	      }
	      if (tAmount.isGreaterThan(0)) {
	        return callback({status : 404, message : 'Not sufficient balance'})
	      }
	      return callback(null, from_addresses, amounts, user)
	    },
	    function(from_addresses, amounts, user, callback) {
	      networkApis.getTransactionCount(user.keys.publicKey, "pending")
	      .then(function(txCount) {
	        // TODO : Call eastimate gas and set gas limits based on that
	        var data = _batchTransferContract.batchTransfer.getData(to_address, tokenAddress, from_addresses, amounts);
					const txData = {
						from: user.keys.publicKey,
						to: user.batchTransferContract,
	          nonce:  networkApis.web3Utils.toHex(txCount),
	          gasPrice: networkApis.web3Utils.toHex(20000000000), // 20 gwei
	          gasLimit: networkApis.web3Utils.toHex(100000),   //145230
	          value:    '0x00',
	          data:     data,
	          chainId: blockchainConfig.CHAIN_ID// Ropsten
	        }
	        // What do u use to sign this ?
	        const {rawTx} = sign(txData, user.keys.privateKey);
					var txPromise = networkApis.eth.sendSignedTransaction('0x' + rawTx);
	        callback(null, txPromise, from_addresses, amounts, user)
	      })
	    },
	    function(txPromise, from_addresses, amounts, user, callback) {
				// send the transaction
	      Token.updateMany({walletAddress : {$in : from_addresses}, tokenAddress : tokenAddress}, {$set : {status : 1}}, function(err) {
	        if (err)
	          return callback({status : 500, message : err})
	        return callback(null, txPromise, from_addresses, amounts)
	      })
	    },
	    function(txPromise, from_addresses, amounts, callback) {
	      txPromise.then(function(receipt) {
	        return callback(null, receipt, from_addresses, amounts)
	      })
	      .catch(function(err) {
	      	// revert
	      	Token.updateMany({walletAddress : {$in : from_addresses}, tokenAddress : tokenAddress}, {$set : {status : 0}}, function(err) {
		        if (err)
		          return callback({status : 500, message : err})
		        // return callback({status : 500, message : err})
		      })

	      })
	    }, function(receipt, from_addresses, amounts, callback) {
				console.log("receipt................",receipt)
	    	if (from_addresses.length) {
	    		async_lib.eachOf(from_addresses, function(address, i, callback) {
	    			Token.findOne({walletAddress : address, tokenAddress : tokenAddress}, function(err, token) {
			    		var tBalance = new BigNumber(token.balance)
			    		token.balance = tBalance.minus(amounts[i])
			    		token.save(function(err) {
			    			if (err)
				          return callback({status : 500, message : err})
				        return callback(null, receipt)
			    		})
			      }, function(err, result) {
			      	if (err) {
			      		console.log(err)
			      		return
			      	}
			      	return callback(null, receipt)
			      })
	    		})
		    	return
		    }
		    return callback(null, receipt)
	    }
	  ], function(err, result) {
	    if (err)
	      return reject(err)
	    return resolve({receipt : result})
	  })
	})
}
module.exports = function(agenda) {
	agenda.define('single withdrawal', function(job, done) {
		var userId = job.attrs.data ? job.attrs.data.userId : ''
		if (!userId){
			return done({error : 'Invalid User Id'})
		}
		User.findById(userId)
	  .then (async function (user, error) {
	  	if (error)
	  		return done("There was a problem finding the user.")
	  	if (!user)
	  		return done('Not a valid user.')
	    queues.withdrawal_queue.get(function(err, msg) {
	    	console.log('comes to this')
	    	console.log(msg)
        if (msg) {
        	withdrawTokenLoop(user, msg)
        	.then(function() {
        		console.log('comes to sart to loop -- success')
        		agenda.now('single withdrawal', {userId : userId})
        		return done()
        	})
        	.catch(function(err) {
        		console.log(err)
        		return done(err)
        	})
        } else {
        	return done()
        }
      });
		})
	})

	agenda.define('batch withdrawls', function(job, done) {
		var userId = job.attrs.data ? job.attrs.data.userId : ''
		var totalAmount = job.attrs.data ? job.attrs.data.totalAmount : '0'
		var tokenAddress = job.attrs.data ? job.attrs.data.tokenAddress : ''
		var to_address = job.attrs.data ? job.attrs.data.to_address : ''
		console.log("userId.............................",userId)
		console.log("totalAmount.............................",totalAmount)
		console.log("tokenAddress.............................",tokenAddress)
		console.log("to_address.............................",to_address)

		if (!userId){
			done({error : 'Invalid User Id'})
		}
		if (!totalAmount){
			done({error : 'Withdrawal amount cannot be zero'})
		}
		if (!tokenAddress){
			done({error : 'Token address is required'})
		}
		if (!to_address){
			done({error : 'To Address address is required'})
		}
		console.log('comes to batch withdrawal')
		batchWithdrawal(userId, totalAmount, tokenAddress, to_address)
		.then(function() {
			console.log("Success")
			console.log(arguments)
			done()
		})
		.catch(function(err) {
			console.log("Error", err);
			console.log(arguments)
			done(err)
		})

	})
}
