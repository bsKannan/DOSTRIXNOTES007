var express = require('express');
var app = express();
var cors = require('cors')
var bodyParser = require('body-parser');
var db = require('./db');
global.__root   = __dirname + '/';

app.use(cors())

app.get('/api', function (req, res) {
  res.status(200).send('API works.');
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use('/api/test', require(__root + 'testing/test_apis'))
var UserController = require(__root + 'user/UserController');
app.use('/api/users', UserController);

var AuthController = require(__root + 'auth/AuthController');
app.use('/api/auth', AuthController);

var WalletController = require(__root + 'wallet/WalletController');
app.use('/api/wallet', WalletController);

var PortfolioController = require(__root + 'portfolio/PortfolioController');
app.use('/api/portfolio', PortfolioController);

var agenda = require('./agenda')

module.exports = app;
