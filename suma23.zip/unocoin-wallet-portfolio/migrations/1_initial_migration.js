var WalletContract = artifacts.require("./WalletContract.sol");

module.exports = function(deployer) {
  deployer.deploy(WalletContract, "0x32d4bd7243876d3e2e5110579589e9d96107690c" , "0x1b9997742d828b5940f4db45524a78f297dd3f44");
};
