var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');

var VerifyToken = require(__root + 'auth/VerifyToken');
const Portfolio = require('../models/portfolio');

router.use(bodyParser.urlencoded({ extended: true }));
var User = require('../models/users');

// Find
router.post('/findPortfolio', function (req, res) {
  if (!req.body) return res.status(500).send("There was a problem gettting the information from the database.");

  if (req.body.columns) {
    columns = JSON.parse(req.body.columns);
  } else {
    columns = {};
  }

  if (req.body.query) {
    query = JSON.parse(req.body.query);
  } else {
    query = {};
  }

  Portfolio.findPortfolio(Portfolio, query, columns)
  .then(function(portfolio, err) {
      if (err) return res.status(500).send(err);
      return res.status(200).send(portfolio);
  });
});

router.get('/findPortfolio', function (req, res) {
      return res.status(200).send("success");
});
module.exports = router;
