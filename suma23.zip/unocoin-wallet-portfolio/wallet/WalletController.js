var express = require('express');
var router = express.Router();


var db = require('../db');
var queues = require('../queues')
const fs = require('fs');
const solc = require('solc');
const web3 = require('../web3service')
const {sign} = require('@warren-bank/ethereumjs-tx-sign');
var async_lib = require('async')
const {promisify} = require("es6-promisify");

const BigNumber = require('bignumber.js')

var VerifyToken = require(__root + 'auth/VerifyToken');
var User = require('../models/users');
var Token = require('../models/tokens');
var Wallet = require('../models/wallets');
var agenda = require('../agenda')

var networkApis = require('../network_apis/production_apis')
var walletConfig = require('../config').walletConfig
var blockchainConfig = require('../config').blockchainConfig

// TODO add ip based access,
// TODO keep contract abi in mongo
// TODO log the request everywhere
// TODO add withdraw token status method
// TODO update the address to tract if new address is added in between
// TODO, give option to ack based on ID too to be on safe side

// https://gist.github.com/xavierlepretre/88682e871f4ad07be4534ae560692ee6
web3.eth.getTransactionReceiptMined = function getTransactionReceiptMined(txHash, interval) {
    const self = this;
    const transactionReceiptAsync = function(resolve, reject) {
        self.getTransactionReceipt(txHash, (error, receipt) => {
            if (error) {
                reject(error);
            } else if (receipt == null) {
                setTimeout(
                    () => transactionReceiptAsync(resolve, reject),
                    interval ? interval : 500);
            } else {
                resolve(receipt);
            }
        });
    };

    if (Array.isArray(txHash)) {
        return Promise.all(txHash.map(
            oneTxHash => self.getTransactionReceiptMined(oneTxHash, interval)));
    } else if (typeof txHash === "string") {
        return new Promise(transactionReceiptAsync);
    } else {
        throw new Error("Invalid Type: " + txHash);
    }
};

// Helper Functions
async function initNewUserContracts(user) {
  // Sanity checks
  if (!user)
    return {error : 'User is missing'}
  if (!user.keys.publicKey)
    return {error : 'User Wallet Address is missing'}

  if (user.batchTransferContact) {
    return new Promise((resolve, reject) => {
      return resolve()
    })
  }

  try {
    let _bal = await networkApis.eth.getBalance(user.keys.publicKey)
    if (_bal <= 0) {
      return new Promise((resolve, reject) => {
        return reject('Insufficent balance in wallet')
      })
    }
  } catch(err) {
    return new Promise((resolve, reject) => {
      return reject(err)
    })
  }
  let batchTransferContactReceipt = ''
  let batchTransferContact = fs.readFileSync(__root + 'contracts/BatchTransfer.sol').toString();
  var checksumAddress = networkApis.web3Utils.toChecksumAddress(user.keys.publicKey)
  batchTransferContact = batchTransferContact.replace(/WALLET_OWNER/g, checksumAddress);
  let {errors, contracts} = solc.compile(batchTransferContact, 1)

  if (errors && errors.length) {
    console.log(errors)
    return {errors : 'Compilation error'}
  }
  let bytecode = contracts[':BatchTransfer'].bytecode;
  try {
    txCount = await networkApis.getTransactionCount(user.keys.publicKey, "pending")
  } catch(err) {
    return {errors : err}
  }

  // TODO : Check Balance
  // TODO : Analyze gas limits

  txData = {
    from : user.keys.publicKey,
    nonce:  networkApis.web3Utils.toHex(txCount),
    gasPrice: networkApis.web3Utils.toHex(26000000000), // 20 gwei
    gasLimit: networkApis.web3Utils.toHex(500000),   //145230
    value:    '0x0',
    data:     '0x' + bytecode,
    chainId: blockchainConfig.CHAIN_ID// Ropsten
  }
  // console.log(txData)
  let {rawTx} = sign(txData, user.keys.privateKey);

  try {
    batchTransferContactReceipt = await networkApis.eth.sendSignedTransaction('0x' + rawTx);
  } catch(err) {
    console.log(err)
    return false
  }

  user.batchTransferContract = batchTransferContactReceipt.contractAddress
  user.currentBlock = batchTransferContactReceipt.blockNumber
  console.log(batchTransferContactReceipt)
  return user.save()

  // TODO : init buffer hardwallets and softwallets
}

// TODO : Make as api
async function initUser(user) {
  // get user
  // get current block number and set to user

  try {
    await initNewUserContracts(user)
    var softWalletsQueue = queues.soft_wallet_queue
    var hardWalletsQueue = queues.hard_wallet_queue
    var softWalletsCount = await promisify(softWalletsQueue.size.bind(softWalletsQueue))()
    var hardWalletsCount = await promisify(hardWalletsQueue.size.bind(hardWalletsQueue))()
    await deployWalletContracts(user, user.hardWalletBuffer - hardWalletsCount, walletConfig.HARD_WALLET) /*for hardwallet buffer */
    await deployWalletContracts(user, user.softWalletBuffer - softWalletsCount, walletConfig.SOFT_WALLET) /*for softwallet buffer */
    return true
  } catch(err) {
    return err
  }

  // list start tracking tx
}

function getHardWalletContractCode(_user) {
  let wc_input = fs.readFileSync(__root + 'contracts/WalletContract.sol').toString();
  wc_input = wc_input.replace(/COLD_WALLET/g, _user.keys.coldWallet);
  wc_input = wc_input.replace(/HOT_WALLET/g, _user.keys.hotWallet);
  wc_input = wc_input.replace(/WALLET_OWNER/g, _user.keys.walletOwner);
  const output = solc.compile(wc_input, 1);
  let bytecode = output.contracts[':WalletContract'].bytecode;
  return bytecode
}

function getSoftWalletContractCode(_user) {
  let wc_input = fs.readFileSync(__root + 'contracts/NWLWalletContract.sol').toString();
  wc_input = wc_input.replace(/WALLET_OWNER/g, _user.batchTransferContract);
  const output = solc.compile(wc_input, 1);
  console.log(output)
  let bytecode = output.contracts[':NWLWalletContract'].bytecode;
  return bytecode
}

function deployWalletContracts(_user, _count, wallet_type) {
  // TODO check if all _user.keys r defined
  // TODO check balance before deploy.
  return new Promise((resolve, reject) => {
    if(!_user.keys.publicKey||!_user.keys.privateKey||!_user.keys.coldWallet||!_user.keys.hotWallet||!_user.keys.walletOwner){
      throw new Error("Keys are not Defined");
    }
    if (_count <= 0)
      return resolve();
    // TODO (Pravin) : Check for gasestimate for total deploys and check for user balance

    networkApis.eth.getBalance(_user.keys.publicKey)
    .then(function(_bal){
      if(_bal<=0){
        return reject({message : "insufficent balance  for trans.",_bal})
      }
      else{
        console.log("balance   ::",_bal);
      }
      let bytecode = wallet_type ? getSoftWalletContractCode(_user) : getHardWalletContractCode(_user)
      let wallet_queue = wallet_type ? queues.soft_wallet_queue : queues.hard_wallet_queue

      for (let i = 0; i < _count; i++) {
        networkApis.getTransactionCount(_user.keys.publicKey, "pending")
        .then(function(txcount) {
          console.log("txcount", txcount);
          const txData = {
            nonce:  networkApis.web3Utils.toHex(txcount + i),
            gasPrice: networkApis.web3Utils.toHex(20000000000), // 20 gwei
            gasLimit: networkApis.web3Utils.toHex(500000),   //145230
            value:    '0x00',
            data:     '0x' + bytecode,
            chainId: CHAINID// Ropsten
          }

          const {rawTx} = sign(txData, _user.keys.privateKey);

          return networkApis.eth.sendSignedTransaction('0x' + rawTx);
        })
        .then (function (receipt, error) {
          if (error) {
              throw { status: 404, json: { message: "There was a problem while deploying contract." }, skip: false };
          }

          receipt.logsBloom = "";
          // remove useless keys and add to queue
          delete receipt.blockHash;
          delete receipt.blockNumber;
          delete receipt.cumulativeGasUsed;
          delete receipt.from;
          delete receipt.gasUsed;
          delete receipt.logs;
          delete receipt.logsBloom;
          delete receipt.to;
          delete receipt.transactionIndex;
          console.log(receipt)
          wallet_queue.add(receipt, function(err, id) {
            // TODO log the status
            console.log("added", err, id);
          });

          return
        })
        .then(function(data, err) {
            // TODO log if any error
            resolve(data)
        })
        .catch (function (error) {
          console.log("catch", error);
          reject(error)
          // TODO log error
          // return res.status(500).send(error);
        });
      }
    })

  })

}

async function addToWallet(userId, addresses, wallet_type) {
  return new Promise((resolve, reject) => {
    if (!userId || !addresses || !addresses.length || typeof wallet_type !== 'number')
      return reject({status : 403, errors : 'Invalid data'})

    Wallet.findOne({user : userId}, function(err, wallet) {
      if (err)
        return reject({status : 500, errors : err})
      if (!wallet)
        wallet = new Wallet({user : userId, softWallets : [], hardWallets : []})
      if (wallet_type == walletConfig.HARD_WALLET) {
        wallet.hardWallets = wallet.hardWallets.concat(addresses)
      } else if (wallet_type == walletConfig.SOFT_WALLET) {
        wallet.softWallets = wallet.softWallets.concat(addresses)
      }
      wallet.save(function(err) {
        if (err)
          return reject({status : 500, errors : err})
        agenda.now('update addresses', {userId : userId})
        return resolve()
      })
    })
  })

}

router.get('/initUser', VerifyToken, function(req, res, next) {

  User.findById(req.userId, function(err, user) {
    initUser(user)
    .then(function() {
      console.log(arguments)
      console.log('Success')
      return res.json({msg: 'Success'})
    })
    .catch(function(err) {
      console.log(arguments)
      console.log('Error')
      return res.json(err)
    })
  })


})

router.post('/deployContract/:wallet_type', VerifyToken, function(req, res, next) {
  let _add_to_wallet = false;
  let _count = 1;
  let wallet_type = isNaN(parseInt(req.params.wallet_type)) ? walletConfig.HARD_WALLET : parseInt(req.params.wallet_type)
  User.findById(req.userId)
  .then (async function (user, error) {
    if (error) throw { status: 404, json: { message: "There was a problem finding the user." }, skip: true };
    if (!user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };

    if (req.body.add_to_wallet && req.body.add_to_wallet == 'true') {
      _add_to_wallet = true;
    }
    if (req.body.count) {
      _count = req.body.count <= walletConfig.MAX_WALLETS_PER_USER ? req.body.count : walletConfig.MAX_WALLETS_PER_USER;
      // TODO also check user addresses buffer setting
      // Here we can check the user buffer
    }
    let status = await deployWalletContracts(user, _count, wallet_type);
    // if (_add_to_wallet)
    //   await addToWallet
    return res.json({'status': status});
  });
});

/* Type :
  0 - Wallet with Hardcoded to_addresses
  1 - Wallet with to_variable
*/
router.get('/getNewWallet/:wallet_type', VerifyToken, function(req, res, next) {
  User.findById(req.userId)
  .then (function (user, error) {
    if (!user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    if (error) throw { status: 404, json: { message: "There was a problem finding the user." }, skip: true };


    let wallet_type = isNaN(parseInt(req.params.wallet_type)) ? walletConfig.HARD_WALLET : parseInt(req.params.wallet_type)

    // check user buffer size setting and deploy need to match it.

    // select queue and buffer based on wallet type
    let wallet_queue = wallet_type ?  queues.soft_wallet_queue : queues.hard_wallet_queue
    let wallet_buffer = wallet_type ? user.softWalletBuffer : user.hardWalletBuffer

    var wallet_count = isNaN(parseInt(req.query.count)) ? wallet_buffer : parseInt(req.query.count)

    wallet_queue.size(async function(err, count) {
      console.log('This queue has %d current messages', count);
      let to_deploy = wallet_buffer - (count - wallet_count)
      console.log(to_deploy);

      if (to_deploy > 0) {
        // TODO : Wait for all the contracts to finish. Then return the wallet
        deployWalletContracts(user, to_deploy, wallet_type); // TODO do not force _add_to_wallet
      }
      // TODO : Get the number of wallets the want (count)
      var messages = []
      var error = false
      for(var i = 0; i < wallet_count; i++) {
        try {
          var msg = await promisify(wallet_queue.get.bind(wallet_queue))()
          delete msg.tries
          messages.push(msg)
        } catch(err){
          error = true
          break;
        }
      }
      if (error) {
        console.log(error)
        return res.status(500).json('Error')
      }
      return res.json(messages)
    });
  })
  .catch(function (error) {
    return res.json({"error:": "error occured"});
  });
});

router.post('/ackNewWallet/:wallet_type', VerifyToken, function(req, res, next) {
  var userId = req.userId
  User.findById(userId)
  .then (async function (user, error) {
    if (!user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    if (error) throw { status: 404, json: { message: "There was a problem finding the user." }, skip: true };

    let wallet_type = isNaN(parseInt(req.params.wallet_type)) ? walletConfig.HARD_WALLET : parseInt(req.params.wallet_type)
    let wallet_queue = wallet_type ?  queues.soft_wallet_queue : queues.hard_wallet_queue
    let ackIDs = JSON.parse(req.body.ackIDs);
    console.log("ackIDs             ;::",ackIDs);
    console.log("wallet_queue             ::",wallet_queue)
    let acked = [];
    var addresses = []
    async_lib.each(ackIDs, function(ack, callback) {
      console.log("ack element  ::",ack)
      wallet_queue.ack(ack, function(err, msg) {
        if (!err)
        console.log("message    ",msg.payload)
          addresses.push(msg.payload.contractAddress)
        callback(null)
      })
    }, function(err, result) {
      console.log("address to add  ",addresses);
      addToWallet(userId, addresses, wallet_type)
      .then(function() {
        if (wallet_type == walletConfig.SOFT_WALLET) {
          agenda.now('schedule transaction tracking', {userId : userId}, function(err, job) {
            return res.json({messages : 'Success'});
          })
        }
        else {
          return res.json({messages : 'Success'});
        }
      })
      .catch(function(err) {
        return res.status(500).json(err)
      })
    })
  })
  .catch(function(err) {
    return res.json(500).json(err)
  })
});

router.get('/startTrackingTxs', VerifyToken, function(req, res, next) {

  agenda.now('schedule transaction tracking', {userId : req.userId}, function(err, job) {
    return res.json({messages : 'Success'});
  })

  // TODO : Is this required ?
});

router.get('/startTrackingPortfolio', VerifyToken, function(req, res, next) {
  agenda.now('schedule portfolio tracking', {userId : req.userId}, function(err, job) {
    return res.json({messages : 'Success'});
  })

  // TODO : Is this required ?
});


router.post('/setCurrentBlock', VerifyToken, function(req, res, next) {
  let block_number = req.body.block_number;
  if (!block_number || block_number < 0) {
    return res.status(500).send("please send block_number");
  }

  User.findById( req.userId)
  .then (function (_user, error) {
    if (!_user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    _user.currentBlock = block_number;

    _user.save(function(err, data) {
        console.log("current block ",err, data);
        res.json("block_number: " + block_number);
    });
  })
  .catch (function (error) {
    console.log("catch", error);
    return res.status(500).json(error);
  });
});

router.get('/getTxsList', VerifyToken, function(req, res, next) {
  User.findById(req.userId)
  .then (function (user, error) {
    if (!user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    if (error) throw { status: 404, json: { message: "There was a problem finding the user." }, skip: true };

    let queue = queues.tx_queue;
    // console.log("queue     ::",queue)
    queue.get(function(err, msg) {
      if(err) return res.status(500).json(err)
      return res.json(msg)
    })
  })
  .catch(function (error) {
    return res.json({"error:": "error occured"});
  });
});

router.post('/getTxs', VerifyToken, function(req, res, next) {
  User.findById(req.userId)
  .then (async function (user, error) {
    if (!user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    if (error) throw { status: 404, json: { message: "There was a problem finding the user." }, skip: true };

    let queue = queues.tx_queue;
    let txHash = req.body.txHash;

    async_lib.waterfall([
      function(callback) {
        // TODO : Fetch the details from web3 again, send the details and mark the item as acked
        callback()
      },
      function(txData, callback) {
        queue.findOneAndAck({txHash : txHash},function(err, acked) {
          if(err) return callback({status : 500, message : err})
            ackedList.push(acked)
            return callback(null, txData)
        })
      }], function(err, txData) {
        if (err)
          return res.status(500).json({err : err})
        return res.json(txData)
    })
  })
  .catch(function (error) {
    return res.json({"error:": "error occured"});
  });
});

router.post('/batchWithdrawal', VerifyToken, function(req, res) {
  let tokenAddress = req.body.tokenAddress
  let totalAmount = req.body.amount ? req.body.amount : '0'
  let to_address = req.body.to_address
console.log("to_address               ",to_address)
console.log("totalAmount               ",totalAmount)
  if (!to_address || !networkApis.web3Utils.isAddress(to_address))
    return res.status(403).json({message : 'Invalid To Address'})

  if (!tokenAddress || !networkApis.web3Utils.isAddress(tokenAddress))
    return res.status(403).json({message : 'Invalid Token Address'})

  var totalAmountBN = new BigNumber(totalAmount)
  console.log("totalAmountBN               ",totalAmountBN)
  if (totalAmountBN.isLessThanOrEqualTo(0))
    return res.status(403).json({message : 'Withdrawal Amount must be greater zero'})


  agenda.now('batch withdrawls', {userId : req.userId, totalAmount : totalAmount, tokenAddress : tokenAddress, to_address : to_address}, function(err, job) {
    return res.json('Success')
  })
})

router.post('/withdrawToken', VerifyToken, function(req, res, next) {
  User.findById(req.userId)
  .then (function (user, error) {
    if (!user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    if (error) throw { status: 404, json: { message: "There was a problem finding the user." }, skip: true };

    let withdrawal_data = JSON.parse(req.body.withdrawal_data);
    if (!withdrawal_data) {
      throw { status: 404, json: { message: "please pass wallet addresses." }, skip: true };
    }

    queues.withdrawal_queue.add(withdrawal_data ,function(err,id) {
      agenda.now('single withdrawal', {userId : user._id})
    });

    return res.json({"status" : "request added to withdraw queue"});
  })
  .catch(function (error) {
    return res.json({"error:": error});
  });
});

router.post('/totalDepositToken', VerifyToken, function(req, res, next) {

  User.findById(req.userId)
  .then (function (_user, error) {
    if (!_user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    if (!error) {

        tokenBalance(_user);
    } else{
    res.write("error");
    res.end();
    }
  })
  .catch (function (error) {
    return res.status(500).send(error);
  });

  function tokenBalance(_user) {

    superagent.get('https://api.etherscan.io/api?module=account&action=tokentx')
      .query(

        {
          contractaddress:req.body.contractaddress,
          address:req.body.address,
          apikey: '8QQNUJAN276SRJ6369XRNSYR7R2XIVMNBI'
        })
        .end((err, response) => {
          if (err) { return console.log(err); }
           var obj1=response.body.result;
           //console.log("object 11 ",obj1);
          var sum=0;
          for(i=0;i<obj1.length;i++){
              //  console.log("sum",obj1[i].value);
                if(obj1[i].to==req.body.address){
                  sum+=parseInt(obj1[i].value);}
               }
             console.log("sum",sum);
           res.json(obj1);
        });
  }

});

router.post('/currentTokenBalance', VerifyToken, function(req, res, next) {

  User.findById(req.userId)
  .then (function (_user, error) {
    if (!_user) throw { status: 404, json: { message: 'Not a valid user.' }, skip: true };
    if (!error) {

        currentBalance(_user);
    } else{
    res.write("error");
    res.end();
    }
  })
  .catch (function (error) {
    return res.status(500).send(error);
  });

  function currentBalance(_user) {

    superagent.get('https://api.etherscan.io/api?module=account&action=tokenbalance')
      .query(

        {
          contractaddress:req.body.contractaddress,
          address:req.body.address,
          apikey: '8QQNUJAN276SRJ6369XRNSYR7R2XIVMNBI'
        })
        .end((err, response) => {
          if (err) { return console.log(err); }
        console.log("response ..  ",response.body.result);

        });
  }

});

module.exports = router;
