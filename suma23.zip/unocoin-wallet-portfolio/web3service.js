const Web3 = require('web3')
const blockchainConfig = require('./config').blockchainConfig
const web3 = new Web3()
web3.setProvider(new web3.providers.HttpProvider(blockchainConfig.RPC_URL));

module.exports = web3