var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var db = require('../db');
var etherscan_api = require('etherscan-api').init('8QQNUJAN276SRJ6369XRNSYR7R2XIVMNBI', 'ropsten');//,'ropsten');
var User = require('../models/users');
var Token = require('../models/tokens');
var Wallet = require('../models/wallets');
var agenda = require('../agenda')
var queues = require('../queues')

var networkApis = require('../network_apis/production_apis')
const {sign} = require('@warren-bank/ethereumjs-tx-sign');
TRANSFER_EVENT_HASH = '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef'

router.get('/sample', function(req, res) {
  console.log(etherscan_api)
  etherscan_api.log.getLogs(null,
    447810,
    447810,
    TRANSFER_EVENT_HASH)
  .then(function(result) {
    console.log('Success')
    console.log(arguments)
    return res.json(result)
  })
  .catch(function(err) {
    console.log('Error')
    console.log(arguments)
    return res.json(err)
  })
})

router.get('/inittx', function(req, res) {
  agenda.now('update addresses', {userId : '5b18eb30dd13a19586679cd5'}, function() {
    agenda.now('track transactions for user', {userId : '5b18eb30dd13a19586679cd5'}, function() {
      return res.json('Success')
    })
  })
})


router.get('/initbatchwithdrawal', function(req, res) {
  var tokenAddress = req.query.tokenAddress
  var to_address = req.query.to_address
  var totalAmount = isNaN(parseInt(req.query.totalAmount)) ? 10 : parseInt(req.query.totalAmount)
  if (!tokenAddress || !to_address)
    return res.status(500).json({message : 'Check params'})
  User.findOne({name : 'test'}, function(err, user) {
    if (!user) {
      console.log('User Not found')
      user = new User({name : 'test', keys : {privateKey : '0x01', walletOwner : '0x02'}, email : 'testing@test.com'})
    }
    var softWallets = require('../sample_logs').softWallets
    var addresses = []
    softWallets.forEach(function(it) {
      it.user = user._id
      addresses.push(it.walletAddress)
    })
    console.log(user)
    user.save(function(err) {
      Wallet.findOne({user : user._id}, function(err, wallet) {
        if (!wallet)
          wallet = new Wallet({user : user._id, softWallets : []})
        wallet.softWallets = addresses
        wallet.save(function() {
          Token.remove({}, function() {
            Token.insertMany(softWallets, function(err) {
              console.log('comes to token save')
              agenda.now('batch withdrawls', {userId : user._id, totalAmount : totalAmount, tokenAddress : tokenAddress, to_address : to_address})
              return res.json('Success')
            })
          })
        })
      })
    })
  })
})

router.get('/initwithdrawals', function(req, res) {
  
  User.findOne({name : 'test'}, function(err, user) {
    if (!user) {
      console.log('User Not found')
      user = new User({name : 'test', keys : {privateKey : '0x01', walletOwner : '0x02'}, email : 'testing@test.com'})
    }
    var hardWallets = require('../sample_logs').hardWallets
    var addresses = []
    hardWallets.forEach(function(it) {
      it.user = user._id
      addresses.push(it.walletAddress)
    })
    console.log(user)
    user.keys['hotWallet'] = '0x03'
    user.keys['coldWallet'] = '0x04'
    user.save(function(err) {
      Wallet.findOne({user : user._id}, function(err, wallet) {
        if (!wallet)
          wallet = new Wallet({user : user._id, softWallets : [], hardWallets : []})
        wallet.hardWallets = addresses
        wallet.save(function() {
          let wt_queue = queues.withdrawal_queue;
          wt_queue.add({
            wallet_address : "0xf06dcd243760d3abc748ae445ea876266a142b99",
            token_address : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
            token_amount : '20'
          }, function(){
              wt_queue.add({
              wallet_address : "0xe9ea50e96fb81432edd6605109257ac71930c574",
              token_address : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
              token_amount : '20'
            }, function() {
              agenda.now('single withdrawal', {userId: user._id}, function() {
                return res.json('Success')
              })
            })
          })
        })
      })
    })
  })
})

router.post('/txping', function(req, res) {
  console.log('Comes to txping')
  console.log(req.body)
  return res.json('Success')
})

router.post('/txpingmain', function(req, res) {
  console.log('Comes to txpingmain')
  console.log(req.body)
  return res.json('Success')
})

router.get('/getlogs' , function(req, res) {
  networkApis.getLogs(null, 3468670, 3468670, TRANSFER_EVENT_HASH)
  .then(function(logs) {
    return res.json(logs)
  })
  .catch(function(err) {
    return res.json(err)
  })
})

router.get('/getblocknumber', function(req, res) {
  networkApis.getBlockNumber()
  .then(function(number) {
    return res.json(number)
  })
  .catch(function(err) {
    return res.json(err)
  })
})

router.get('/getTransactionCount', function(req, res) {
  networkApis.getTransactionCount("0x81b7E08F65Bdf5648606c89998A9CC8164397647")
  .then(function(number) {
    return res.json(number)
  })
  .catch(function(err) {
    return res.json(err)
  })
})

router.get('/getBalance', function(req, res) {
  networkApis.eth.getBalance("0x81b7E08F65Bdf5648606c89998A9CC8164397647")
  .then(function(number) {
    return res.json(number)
  })
  .catch(function(err) {
    return res.json(err)
  })
})

router.get('/sendSignedTransaction', function(req, res) {
  networkApis.getTransactionCount('0xf0669c649c421c5d71a19cb66fd1768C4AF4e33F', "pending")
  .then(function(txcount) {
    const txData = {
      from: '0xf0669c649c421c5d71a19cb66fd1768C4AF4e33F',
      nonce:  networkApis.web3Utils.toHex(txcount),
      gasPrice: networkApis.web3Utils.toHex(20000000000), // 20 gwei
      to: '0x5BaC163e40F4ADEaC75A1Df435f612067cF25e6F',
      gasLimit: networkApis.web3Utils.toHex(4000000),   //145230
      value:    '0x4A817C800',
      chainId: '0x03'// Ropsten
    }
    let {rawTx} = sign(txData, '84D1B4C333E98A4581891C811EC4C73F750E1313D7F32B583FAA2CCC32692E0D');
    networkApis.eth.sendSignedTransaction('0x' + rawTx)
    .then(function(receipt) {
      return res.json(receipt)
    })
    .catch(function(err) {
      return res.json(err)
    })
  })
  
})






module.exports = router;