var tokenAddress = [
	"0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	"0x9b10301e990840cc78eab1ed2d0fcbede8ff219c"
]

var walletAddress2 = [{
  "0xf06dcd243760d3abc748ae445ea876266a142b99": {
    "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c": "20"
  },
  "0xe9ea50e96fb81432edd6605109257ac71930c574": {
    "0x9b10301e990840cc78eab1ed2d0fcbede8ff219c": "30",
    "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c": "10"
  }
}]

var walletAddress1 = [{
  "0xf06dcd243760d3abc748ae445ea876266a142b99": {
    "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c": "20"
  },
  "0xe9ea50e96fb81432edd6605109257ac71930c574": {
    "0x9b10301e990840cc78eab1ed2d0fcbede8ff219c": "10"
  }
}]


exports.tx = {
	1 : [{
	    "address": "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	    "topics": [
	      "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
	      "0x0000000000000000000000000000000000000000000000000000000000000001",
	      "0x000000000000000000000000f06dcd243760d3abc748ae445ea876266a142b99",
	    ],
	    "data": "0x000000000000000000000000000000000000000000000000000000000000000a",
	    "blockNumber": "0x6d542",
	    "timeStamp": "0x589098b9",
	    "gasPrice": "0x4a817c800",
	    "gasUsed": "0xc30f",
	    "logIndex": "0x1",
	    "transactionHash": "0x4d6715d6315d4271e9a122bda8193fcff3a613c2e4203af69affd1f566d5e939",
	    "transactionIndex": "0x2"
  	},
  	{
	    "address": "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	    "topics": [
	      "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
	      "0x0000000000000000000000000000000000000000000000000000000000000001",
	      "0x000000000000000000000000f06dcd243760d3abc748ae445ea876266a142b99",
	    ],
	    "data": "0x000000000000000000000000000000000000000000000000000000000000000a",
	    "blockNumber": "0x6d542",
	    "timeStamp": "0x589098b9",
	    "gasPrice": "0x4a817c800",
	    "gasUsed": "0xc30f",
	    "logIndex": "0x1",
	    "transactionHash": "0x4d6715d6315d4271e9a122bda8193fcff3a613c2e4203af69affd1f566d5e939",
	    "transactionIndex": "0x2"
  	},
  	{
	    "address": "0x9b10301e990840cc78eab1ed2d0fcbede8ff219c",
	    "topics": [
	      "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
	      "0x0000000000000000000000000000000000000000000000000000000000000001",
	      "0x000000000000000000000000e9ea50e96fb81432edd6605109257ac71930c574"
	    ],
	    "data": "0x000000000000000000000000000000000000000000000000000000000000000a",
	    "blockNumber": "0x6d542",
	    "timeStamp": "0x589098b9",
	    "gasPrice": "0x4a817c800",
	    "gasUsed": "0xc30f",
	    "logIndex": "0x1",
	    "transactionHash": "0x4d6715d6315d4271e9a122bda8193fcff3a613c2e4203af69affd1f566d5e939",
	    "transactionIndex": "0x2"
  	}
	],
	2 : [{
	    "address": "0x9b10301e990840cc78eab1ed2d0fcbede8ff219c",
	    "topics": [
	      "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
	      "0x0000000000000000000000000000000000000000000000000000000000000001",
	      "0x000000000000000000000000e9ea50e96fb81432edd6605109257ac71930c574"
	    ],
	    "data": "0x000000000000000000000000000000000000000000000000000000000000000a",
	    "blockNumber": "0x6d542",
	    "timeStamp": "0x589098b9",
	    "gasPrice": "0x4a817c800",
	    "gasUsed": "0xc30f",
	    "logIndex": "0x1",
	    "transactionHash": "0x4d6715d6315d4271e9a122bda8193fcff3a613c2e4203af69affd1f566d5e939",
	    "transactionIndex": "0x2"
  	},
  	{
	    "address": "0x9b10301e990840cc78eab1ed2d0fcbede8ff219c",
	    "topics": [
	      "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
	      "0x0000000000000000000000000000000000000000000000000000000000000001",
	      "0x000000000000000000000000e9ea50e96fb81432edd6605109257ac71930c574"
	    ],
	    "data": "0x000000000000000000000000000000000000000000000000000000000000000a",
	    "blockNumber": "0x6d542",
	    "timeStamp": "0x589098b9",
	    "gasPrice": "0x4a817c800",
	    "gasUsed": "0xc30f",
	    "logIndex": "0x1",
	    "transactionHash": "0x4d6715d6315d4271e9a122bda8193fcff3a613c2e4203af69affd1f566d5e939",
	    "transactionIndex": "0x2"
  	},
  	{
	    "address": "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	    "topics": [
	      "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef",
	      "0x0000000000000000000000000000000000000000000000000000000000000001",
	      "0x000000000000000000000000e9ea50e96fb81432edd6605109257ac71930c574"
	    ],
	    "data": "0x000000000000000000000000000000000000000000000000000000000000000a",
	    "blockNumber": "0x6d542",
	    "timeStamp": "0x589098b9",
	    "gasPrice": "0x4a817c800",
	    "gasUsed": "0xc30f",
	    "logIndex": "0x1",
	    "transactionHash": "0x4d6715d6315d4271e9a122bda8193fcff3a613c2e4203af69affd1f566d5e939",
	    "transactionIndex": "0x2"
  	}
	],
}

exports.softWallets = [{
	walletAddress : "0xf06dcd243760d3abc748ae445ea876266a142b99",
	tokenAddress : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "20"
},
{
	walletAddress : "0xe9ea50e96fb81432edd6605109257ac71930c574",
	tokenAddress : "0x9b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "20"
},
{
	walletAddress : "0xe9ea50e96fb81432edd6605109257ac71930c574",
	tokenAddress : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "10"
}]

exports.hardWallets = [{
	walletAddress : "0xf06dcd243760d3abc748ae445ea876266a142b99",
	tokenAddress : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "20"
},
{
	walletAddress : "0xe9ea50e96fb81432edd6605109257ac71930c574",
	tokenAddress : "0x9b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "20"
},
{
	walletAddress : "0xe9ea50e96fb81432edd6605109257ac71930c574",
	tokenAddress : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "10"
},
{
	// hotwallet
	walletAddress : "0x03",
	tokenAddress : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "10"
},
{
	// coldwallet
	walletAddress : "0x04",
	tokenAddress : "0x8b10301e990840cc78eab1ed2d0fcbede8ff219c",
	balance : "100"
}]









