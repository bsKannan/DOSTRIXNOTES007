var mongoose = require('mongoose')
var Schema = mongoose.Schema,
	ObjectId = Schema.Types.ObjectId;
const BigNumberSchema = require('mongoose-bignumber')


var tokenSchema = new Schema({
	user : {type : ObjectId, ref : 'User'},
	tokenAddress : String,
	walletAddress : String,
	balance : BigNumberSchema, /* sort based */
	status : {type : Number, default : 0}, /* 0 - clean, 1 - in progress */
})

module.exports = mongoose.model('Token', tokenSchema);