var mongoose = require('mongoose')
var Schema = mongoose.Schema;

var portfolioSchema = new Schema({
  name: String,
  contractAddress: {
    type: String,
    required: true,
    trim: true,
    unique: true,
  },
  maker: String,
  fee: String,
  hash: {
    type:String,
    required: true,
  },
  message: String,
  owner: String,
  currentOwnerOrSeller: String,
  valueInEther: String,
  expiresAt: Number,
  tokens: Object,
  lastUpdated: String,
  status: String
});

function findPortfolio(Portfolio, query, columns) {
  return Portfolio.find(query, columns);
}

module.exports = mongoose.model('Portfolio', portfolioSchema);
module.exports.findPortfolio = findPortfolio;
/*
{ maker: '0x150d925ed766740b909f6bc6216a9d2127bd46d1',
contractAddress: '0x72d06584e04a5ced93740819b0d409b0d3bdf44f',
fee: '0x58d15e17628000',
hash: '0xade0723592fda02e8a9cfd20a9cbb6fd856a4e7bddc9634944244a44858e2df0',
message: '0x4558473030303100000000000000000000000000000000000000000000000000',
owner: '0x150d925ed766740b909f6bc6216a9d2127bd46d1',
currentOwnerOrSeller: '0x150d925ed766740b909f6bc6216a9d2127bd46d1',
valueInEther: BigNumber { s: 1, e: 0, c: [ 1 ] },
expiresAt: '3537718',
name: 'wandx-meta-mask12122',
tokens: [] }*/
