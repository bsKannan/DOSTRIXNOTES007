var mongoose = require('mongoose');
const walletConfig = require('../config').walletConfig
// TODO make cw & hw and list and set one as active
var UserSchema = new mongoose.Schema({
  name: {
      type:String,
      required: true
  },
  email: {
      type:String,
      required: true,
      unique: true
  },
  password: String,
  keys: {
    publicKey: String,
    privateKey: String,
    coldWallet: String,
    hotWallet: String,
    walletOwner: String,
    userWallet: String
  },
  currentBlock: {type : Number, default : 1}, /* change the default value to something more relevent */
  hardWalletBuffer: {type : Number, default : walletConfig.MAX_HARWALLETS_PER_USER},
  softWalletBuffer: {type : Number, default : walletConfig.MAX_SOFTWALLETS_PER_USER},
  batchTransferContract : String,
},
{
    timestamps: true
});

function findUserByID(User, id) {
  return User.findById(id, { password: 0, wallets: 0, deployed: 0});
}

function findUserByEmail(User, _email) {
  return User.findOne({ email: _email }, { wallets: 0, deployed: 0});
}

function findAddressToTrack(User, id) {
  return User.findById(id, { wallets: 1, currentBlock: 1});
}

mongoose.model('User', UserSchema);

module.exports = mongoose.model('User');
module.exports.findUserByID = findUserByID;
module.exports.findUserByEmail = findUserByEmail;
module.exports.findAddressToTrack = findAddressToTrack;
