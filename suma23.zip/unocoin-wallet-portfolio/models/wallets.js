var mongoose = require('mongoose')
var Schema = mongoose.Schema,
	ObjectId = Schema.Types.ObjectId;


var walletSchema = new Schema({
	user : {type : ObjectId, ref : 'User'},
	softWallets : [String],
	hardWallets : [String]
})

module.exports = mongoose.model('Wallet', walletSchema);