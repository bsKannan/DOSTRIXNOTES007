
var BigNumber = require('bignumber.js')
var web3 = require('./web3Service')

const SIMPLE_GAS_COST = '0x5208'
BigNumber.config({
  ROUNDING_MODE: BigNumber.ROUND_HALF_DOWN,
})

function stripHexPrefix(str) {
  if (typeof str !== 'string')
    return str;

  return str.slice(0, 2) === '0x' ? str.slice(0, 2) : str
}
function addHexPrefix(str) {
  if (typeof str !== 'string')
    return str;
  return str.slice(0, 2) === '0x' ? str : '0x' + str
}
function BnMultiplyByFraction (targetBN, numerator, denominator) {
  const numBN = new BigNumber(numerator)
  const denomBN = new BigNumber(denominator)
  return targetBN.times(numBN).div(denomBN).round()
}
function bnToHex (inputBn) {
  return ethUtil.addHexPrefix(inputBn.toString(16))
}

function hexToBn (inputHex) {
  return new BigNumber(stripHexPrefix(inputHex), 16)
}
async function estimateTxGas (txParams, blockGasLimitHex) {

//  recipient - batchtranfer address

  // if recipient has no code, gas is 21k max:
  const recipient = txParams.to
  const hasRecipient = Boolean(recipient)
  const code = await web3.eth.getCode(recipient)
  if (hasRecipient && (!code || code === '0x')) {
    txParams.gas = SIMPLE_GAS_COST
    return SIMPLE_GAS_COST
  }

  // if not, fall back to block gasLimit
  const blockGasLimitBN = (blockGasLimitHex)
  const saferGasLimitBN = this.BnMultiplyByFraction(blockGasLimitBN, 19, 20)
  txParams.gas = this.bnToHex(saferGasLimitBN)

  // run tx
  return await web3.eth.estimateGas(txParams)
}

function addGasBuffer (initialGasLimitHex, blockGasLimitHex) {
  const initialGasLimitBn = hexToBn(initialGasLimitHex)
  const blockGasLimitBn = hexToBn(blockGasLimitHex)
  const upperGasLimitBn = blockGasLimitBn.times(0.9)
  const bufferedGasLimitBn = initialGasLimitBn.times(1.5)

  // if initialGasLimit is above blockGasLimit, dont modify it
  if (initialGasLimitBn.gt(upperGasLimitBn)) return bnToHex(initialGasLimitBn)
  // if bufferedGasLimit is below blockGasLimit, use bufferedGasLimit
  if (bufferedGasLimitBn.lt(upperGasLimitBn)) return bnToHex(bufferedGasLimitBn)
  // otherwise use blockGasLimit
  return bnToHex(upperGasLimitBn)
}

function setTxGas (txMeta, blockGasLimitHex, estimatedGasHex) {
  txMeta.estimatedGas = ethUtil.addHexPrefix(estimatedGasHex)
  const txParams = txMeta.txParams

  // if gasLimit was specified and doesnt OOG,
  // use original specified amount
  if (txMeta.gasLimitSpecified || txMeta.simpleSend) {
    txMeta.estimatedGas = txParams.gas
    return
  }
  // if gasLimit not originally specified,
  // try adding an additional gas buffer to our estimation for safety
  const recommendedGasHex = addGasBuffer(txMeta.estimatedGas, blockGasLimitHex)
  txParams.gas = recommendedGasHex
  return
}


async function analyzeGasUsage (txMeta) {
  const block = await web3.eth.getBlock('latest')
  let estimatedGasHex
  try {
    estimatedGasHex = await estimateTxGas(txMeta, block.gasLimit)
  } catch (err) {
    const simulationFailed = (
      err.message.includes('Transaction execution error.') ||
      err.message.includes('gas required exceeds allowance or always failing transaction')
    )
    if (simulationFailed) {
      txMeta.simulationFails = true
      return txMeta
    }
  }
  setTxGas(txMeta, block.gasLimit, estimatedGasHex)
  return txMeta
}


async function addTxDefaults (txMeta) {
  const txParams = txMeta.txParams
  // ensure value
  txMeta.gasPriceSpecified = Boolean(txParams.gasPrice)
  txMeta.nonceSpecified = Boolean(txParams.nonce)
  let gasPrice = txParams.gasPrice
  if (!gasPrice) {
    gasPrice = await web3.eth.gasPrice()
  }
  txParams.gasPrice = ethUtil.addHexPrefix(gasPrice.toString(16))
  txParams.value = txParams.value || '0x0'
  // set gasLimit
  return await analyzeGasUsage(txMeta)
}