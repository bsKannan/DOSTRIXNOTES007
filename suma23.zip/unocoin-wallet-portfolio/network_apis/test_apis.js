const web3 = require('../web3service')

exports.getBlockNumber = function() {
	return new Promise((resolve, reject) => {
		setTimeout(() => {
			console.log('Timeout resolve')
			resolve(0x2)
		},10)
	})
}
exports.getLogs = function(address,
        fromBlock,
        toBlock,
        topic0
      ) {
	return new Promise((resolve, reject) => {
		var logs = require('../sample_logs').tx
		if (logs[fromBlock])
			return resolve({result : logs[fromBlock]})
		return reject("No records found")

	})
}
exports.web3Utils = web3.utils

exports.getTransactionCount = function() {
	return new Promise((resolve, reject) => {
		setTimeout(function() {
			resolve(1)
		}, 1000)
	})
}
exports.hardWallets = require('../sample_logs').hardWallets
exports.eth = {
	sendSignedTransaction : function() {
		return new Promise((resolve, reject) => {
			setTimeout(function() {
				resolve({
			    blockHash: '0x9bdee59895f9fac526800fd7ea5cc45cb491f7aca6836672eadf9ced92f4bc9d',
			    blockNumber: 3391338,
			    contractAddress: '0x21810d74a77364924B9fACfC72ea2B8285f0884e',
			    cumulativeGasUsed: 308461,
			    from: '0xe73269af00393ea82c735615393ae55fb573c7ea',
			    gasUsed: 287461,
			    logs: [],
			    logsBloom: '0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000',
			    status: true,
			    to: null,
			    transactionHash: '0x5ef0f83e9f17ef44f9b70641b22140e7e5375ca7e9c77494d603b659d61a3bf5',
			    transactionIndex: 1
			})
			}, 1000)
		})
	},
	getBalance : function() {
		return new Promise((resolve, reject) {
			return resolve(10)
		})
	}
	Contract : function() {
		return {
			methods : {
				'batchTransfer' : function(to_address, from_addresses, amount) {
					return {
						encodeABI : function() {
							return JSON.stringify({
								to_address, from_addresses, amount
							})
						}
					}
				},
				'getBalance' : function(token_address,wallet_address) {
					return {
						call : function() {
							return new Promise((resolve, reject) => {
								var item = false
								console.log()
								exports.hardWallets.forEach(function(it) {
									if (it.walletAddress == wallet_address && it.tokenAddress == token_address) {
										item = it
									}
								})
								if (item)
									resolve(item.balance)
								else resolve(0)
							})
						}
					}
				},
				'takeAssetOut' : function(token_address, token_amount, to_cold_wallet) {
				return {
					encodeABI : function() {
						return JSON.stringify({
							token_address, token_amount, to_cold_wallet
						})
					}
				}
			}
			}
		}
	},


}

