// const web3 = require('../web3service')
// var etherscan_api = require('etherscan-api').init('8QQNUJAN276SRJ6369XRNSYR7R2XIVMNBI', 'ropsten');

// // exports.getBlockNumber = etherscan_api.proxy.eth_blockNumber
// // exports.getLogs = etherscan_api.log.getLogs
// exports.getBlockNumber = web3.eth.getBlockNumber
// exports.getLogs = function(address, fromBlock, toBlock, topic0) {
// 	//console.log.log(fromBlock, toBlock, topic0)
// 	return web3.eth.getPastLogs({
// 		fromBlock,
// 		toBlock,
// 		topics : [topic0]
// 	})
// 	// return new Promise((resolve, reject) => {
// 	// 	var filter = web3.eth.filter({
// 	// 		fromBlock,
// 	// 		toBlock,
// 	// 		topics : [topic0]
// 	// 	})
// 	// 	filter.get(function(err, logs) {
// 	// 		if (err)
// 	// 			return reject(err)
// 	// 		return resolve(logs)
// 	// 	})
// 	// })
// }
// exports.web3Utils = web3.utils
// exports.getTransactionCount = web3.eth.getTransactionCount
// exports.eth = {
// 	'Contract' : web3.eth.Contract,
// 	'sendSignedTransaction' : web3.eth.sendSignedTransaction,
// 	'getBalance' : web3.eth.getBalance
// }
var numberToBN = require('number-to-bn');
const web3 = require('../web3service')
const web3Utils = require('./web3Utils')
var etherscan_api = require('etherscan-api').init('8QQNUJAN276SRJ6369XRNSYR7R2XIVMNBI', 'ropsten');
const {promisify} = require("es6-promisify");

// exports.getBlockNumber = etherscan_api.proxy.eth_blockNumber
// exports.getLogs = etherscan_api.log.getLogs
exports.getBlockNumber = function() {
	return new Promise((resolve, reject) => {
		var blockNumber = web3.eth.getBlockNumber(function(err, blockNumber) {
			if (err)
				return reject(err)
			return resolve(blockNumber)
		})

	})
}
exports.getLogs = function(address, fromBlock, toBlock, topic0) {
	return new Promise((resolve, reject) => {
	//	console.log('comes to this')
		var filter = web3.eth.filter({
			fromBlock,
			toBlock,
			topics : [topic0]
		})
		//console.log(filter)
		filter.get(function(err, logs) {
			// console.log(err)
			//console.log.log(logs)
			if (err)
				return reject(err)
			return resolve(logs)
		})
	})
}
exports.web3Utils = web3Utils
exports.web3Utils['toChecksumAddress'] = web3.toChecksumAddress
exports.getTransactionCount = async function(address, defaultBlock) {
	return new Promise((resolve, reject) => {
		web3.eth.getTransactionCount(address, function(err, number) {
			if (err)
				return reject(err)
			return resolve(number)
		})
	})
}
exports.eth = {}
exports.eth.getContract = function(apiArray, address, options) {
	var contract = web3.eth.contract(apiArray)
	return contract.at(address)
}
exports.eth.sendSignedTransaction = function(txdata){
	console.log('comes to sendSignedTransaction')
	// var txdataSr = t
	return new Promise((resolve, reject) => {
		console.log('comes to sendSignedTransaction 1')
		let txHash = ''
		function getReceipt(hash) {
			setTimeout(function() {
			//	//console.log.log(txHash)
				web3.eth.getTransactionReceipt(txHash, function(err, reciept) {
					////console.log.log.log(reciept)
					if (!reciept)
						return getReceipt()
					return resolve(reciept)
				})
			}, 500)
		}
		web3.eth.sendRawTransaction(txdata, function(err, txHa) {
			////console.log.log.log(txHa)
			//console.log.log(err)
			if (err)
				return reject(err)
			txHash = txHa
			//console.log.log(txHa)
			getReceipt()
		})
	})
}
exports.eth.getBalance = function(address){
	return new Promise((resolve, reject) => {
		web3.eth.getBalance(address, function(err, balance) {
			if(err)
				return reject(err)
			return resolve(balance)
		})
	})
}
